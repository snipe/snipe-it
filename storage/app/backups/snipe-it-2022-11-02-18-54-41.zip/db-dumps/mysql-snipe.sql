
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(20,2) DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `min_amt` int(11) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `model_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `accessories_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accessories` WRITE;
/*!40000 ALTER TABLE `accessories` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accessories_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accessories_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accessories_users` WRITE;
/*!40000 ALTER TABLE `accessories_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `action_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` int(11) DEFAULT NULL,
  `target_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `filename` text COLLATE utf8mb4_unicode_ci,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `expected_checkin` date DEFAULT NULL,
  `accepted_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `thread_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `accept_signature` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_meta` text COLLATE utf8mb4_unicode_ci,
  `action_date` datetime DEFAULT NULL,
  `stored_eula` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `action_logs_thread_id_index` (`thread_id`),
  KEY `action_logs_created_at_index` (`created_at`),
  KEY `action_logs_item_type_item_id_action_type_index` (`item_type`,`item_id`,`action_type`),
  KEY `action_logs_target_type_target_id_action_type_index` (`target_type`,`target_id`,`action_type`),
  KEY `action_logs_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `action_logs_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `action_logs` WRITE;
/*!40000 ALTER TABLE `action_logs` DISABLE KEYS */;
INSERT INTO `action_logs` VALUES (1,1,'create',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-21 11:23:16','2022-10-21 11:23:16',NULL,NULL,2,NULL,NULL,NULL,NULL),(2,1,'checkout',1063,'App\\Models\\Location',1063,'Checked out on asset creation',NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-21 11:23:16','2022-10-21 11:23:16',NULL,NULL,NULL,NULL,NULL,'2022-10-21 12:23:16',NULL),(3,1,'update',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-21 13:08:11','2022-10-21 13:08:11',NULL,NULL,2,NULL,'{\"company_id\":{\"old\":2,\"new\":\"6\"}}',NULL,NULL),(4,1,'update',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-22 21:06:18','2022-10-22 21:06:18',NULL,NULL,6,NULL,'{\"status_id\":{\"old\":2,\"new\":\"3\"}}',NULL,NULL),(5,1,'update',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-22 21:07:11','2022-10-22 21:07:11',NULL,NULL,6,NULL,'{\"status_id\":{\"old\":3,\"new\":\"2\"}}',NULL,NULL),(6,1,'checkin from',1063,'App\\Models\\Location',NULL,NULL,NULL,'App\\Models\\Asset',1,NULL,NULL,'2022-10-22 21:23:04','2022-10-22 21:23:04',NULL,NULL,NULL,NULL,NULL,'2022-10-22 22:23:04',NULL),(7,1,'create',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',2,NULL,NULL,'2022-10-22 21:24:07','2022-10-22 21:24:07',NULL,NULL,6,NULL,NULL,NULL,NULL),(8,1,'delete',NULL,NULL,NULL,NULL,NULL,'App\\Models\\Asset',2,NULL,NULL,'2022-10-22 21:24:18','2022-10-22 21:24:18',NULL,NULL,6,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `action_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asset_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_id` int(11) NOT NULL,
  `checkedout_to` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `asset_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `filename` text COLLATE utf8mb4_unicode_ci,
  `requested_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `accepted_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `component_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asset_logs` WRITE;
/*!40000 ALTER TABLE `asset_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_maintenances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `asset_maintenance_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_warranty` tinyint(1) NOT NULL,
  `start_date` date NOT NULL,
  `completion_date` date DEFAULT NULL,
  `asset_maintenance_time` int(11) DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `cost` decimal(20,2) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asset_maintenances` WRITE;
/*!40000 ALTER TABLE `asset_maintenances` DISABLE KEYS */;
INSERT INTO `asset_maintenances` VALUES (1,1,2,'Réparation','test',1,'2022-10-04',NULL,NULL,NULL,NULL,NULL,'2022-10-21 14:16:27','2022-10-22 21:07:49',2);
/*!40000 ALTER TABLE `asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asset_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_id` int(11) NOT NULL,
  `filenotes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asset_uploads` WRITE;
/*!40000 ALTER TABLE `asset_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_uploads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asset_tag` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(20,2) DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `physical` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `warranty_months` int(11) DEFAULT NULL,
  `depreciate` tinyint(1) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `requestable` tinyint(4) NOT NULL DEFAULT '0',
  `rtd_location_id` int(11) DEFAULT NULL,
  `_snipeit_mac_address_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accepted` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_checkout` datetime DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `assigned_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_audit_date` datetime DEFAULT NULL,
  `next_audit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `checkin_counter` int(11) NOT NULL DEFAULT '0',
  `checkout_counter` int(11) NOT NULL DEFAULT '0',
  `requests_counter` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_rtd_location_id_index` (`rtd_location_id`),
  KEY `assets_assigned_type_assigned_to_index` (`assigned_type`,`assigned_to`),
  KEY `assets_created_at_index` (`created_at`),
  KEY `assets_deleted_at_status_id_index` (`deleted_at`,`status_id`),
  KEY `assets_deleted_at_model_id_index` (`deleted_at`,`model_id`),
  KEY `assets_deleted_at_assigned_type_assigned_to_index` (`deleted_at`,`assigned_type`,`assigned_to`),
  KEY `assets_deleted_at_supplier_id_index` (`deleted_at`,`supplier_id`),
  KEY `assets_deleted_at_location_id_index` (`deleted_at`,`location_id`),
  KEY `assets_deleted_at_rtd_location_id_index` (`deleted_at`,`rtd_location_id`),
  KEY `assets_deleted_at_asset_tag_index` (`deleted_at`,`asset_tag`),
  KEY `assets_deleted_at_name_index` (`deleted_at`,`name`),
  KEY `assets_serial_index` (`serial`),
  KEY `assets_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,NULL,'00001',1,'1607370','2018-05-02',NULL,'591/SAM/GR/2017',NULL,'reference d\'affectation',NULL,1,'2022-10-21 11:23:16','2022-10-22 21:23:04',1,NULL,2,0,NULL,0,1,0,1063,NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,1063,1,1,0),(2,NULL,'00002',1,NULL,'2018-05-02',NULL,'591/SAM/GR/2017',NULL,'reference d\'affectation',NULL,1,'2022-10-22 21:24:07','2022-10-22 21:24:18',1,'2022-10-22 21:24:18',2,0,NULL,0,1,0,1063,NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,1063,0,0,0);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `eula_text` longtext COLLATE utf8mb4_unicode_ci,
  `use_default_eula` tinyint(1) NOT NULL DEFAULT '0',
  `require_acceptance` tinyint(1) NOT NULL DEFAULT '0',
  `category_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'asset',
  `checkin_email` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Misc Software','2022-10-17 17:20:27','2022-10-21 08:40:44',NULL,'2022-10-21 08:40:44',NULL,0,0,'license',0,NULL),(2,'Souris','2022-10-21 08:47:33','2022-10-21 08:47:33',1,NULL,NULL,0,0,'asset',0,'category-image-gAH0PNSsDu.png'),(3,'Clavier','2022-10-21 08:48:32','2022-10-21 08:48:32',1,NULL,NULL,0,0,'asset',0,'category-image-4uSjy8rxdb.png'),(4,'Appareil Photo','2022-10-21 08:49:19','2022-10-21 08:49:19',1,NULL,NULL,0,0,'asset',0,'category-image-DZlnhJ3WSt.png'),(5,'Camescope','2022-10-21 08:49:57','2022-10-21 08:49:57',1,NULL,NULL,0,0,'asset',0,'category-image-FqKYqS7m0m.png'),(6,'Imprimante','2022-10-21 08:50:21','2022-10-21 08:50:21',1,NULL,NULL,0,0,'asset',0,'category-image-nNdKgFUfOx.png'),(7,'Micro','2022-10-21 08:50:40','2022-10-21 08:50:40',1,NULL,NULL,0,0,'asset',0,'category-image-FX46MPGofu.png'),(8,'Moniteur','2022-10-21 08:51:00','2022-10-21 08:51:00',1,NULL,NULL,0,0,'asset',0,'category-image-EtkJV3YkMM.png'),(9,'Onduleur','2022-10-21 08:51:22','2022-10-21 08:51:22',1,NULL,NULL,0,0,'asset',0,'category-image-ExwHUMWFZF.png'),(10,'PC Bureau','2022-10-21 08:51:35','2022-10-21 08:51:35',1,NULL,NULL,0,0,'asset',0,'category-image-hREXfcQzdD.png');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `checkout_acceptances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkout_acceptances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `checkoutable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkoutable_id` bigint(20) unsigned NOT NULL,
  `assigned_to_id` int(11) DEFAULT NULL,
  `signature_filename` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `declined_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `stored_eula` text COLLATE utf8mb4_unicode_ci,
  `stored_eula_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `checkout_acceptances_checkoutable_type_checkoutable_id_index` (`checkoutable_type`,`checkoutable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `checkout_acceptances` WRITE;
/*!40000 ALTER TABLE `checkout_acceptances` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkout_acceptances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `checkout_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkout_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `requestable_id` int(11) NOT NULL,
  `requestable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `canceled_at` datetime DEFAULT NULL,
  `fulfilled_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `checkout_requests_user_id_requestable_id_requestable_type` (`user_id`,`requestable_id`,`requestable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `checkout_requests` WRITE;
/*!40000 ALTER TABLE `checkout_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkout_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Maintenance','2022-10-21 09:33:14','2022-10-21 09:33:14',NULL),(2,'Magasin','2022-10-21 09:33:22','2022-10-21 09:33:22',NULL),(3,'Informatique','2022-10-21 09:33:30','2022-10-21 09:33:30',NULL),(4,'Archivage','2022-10-21 09:33:40','2022-10-21 09:33:40',NULL),(5,'Drones','2022-10-21 09:33:46','2022-10-21 09:33:46',NULL),(6,'CPI','2022-10-21 09:33:53','2022-10-21 09:33:53',NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '1',
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(20,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `min_amt` int(11) DEFAULT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `components_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `components` WRITE;
/*!40000 ALTER TABLE `components` DISABLE KEYS */;
/*!40000 ALTER TABLE `components` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `components_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `assigned_qty` int(11) DEFAULT '1',
  `component_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `components_assets` WRITE;
/*!40000 ALTER TABLE `components_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `components_assets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(20,2) DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `min_amt` int(11) DEFAULT NULL,
  `model_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `item_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `consumables_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `consumables` WRITE;
/*!40000 ALTER TABLE `consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `consumables_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumables_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `consumables_users` WRITE;
/*!40000 ALTER TABLE `consumables_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `custom_field_custom_fieldset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_field_custom_fieldset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `custom_fieldset_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `custom_field_custom_fieldset` WRITE;
/*!40000 ALTER TABLE `custom_field_custom_fieldset` DISABLE KEYS */;
INSERT INTO `custom_field_custom_fieldset` VALUES (1,1,1,1,0);
/*!40000 ALTER TABLE `custom_field_custom_fieldset` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `field_values` text COLLATE utf8mb4_unicode_ci,
  `field_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `db_column` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help_text` text COLLATE utf8mb4_unicode_ci,
  `show_in_email` tinyint(1) NOT NULL DEFAULT '0',
  `is_unique` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (1,'MAC Address','regex:/^[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}$/','text',NULL,'2022-10-17 17:20:24',NULL,NULL,0,'_snipeit_mac_address_1',NULL,0,0);
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `custom_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_fieldsets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `custom_fieldsets` WRITE;
/*!40000 ALTER TABLE `custom_fieldsets` DISABLE KEYS */;
INSERT INTO `custom_fieldsets` VALUES (1,'Asset with MAC Address',NULL,NULL,NULL);
/*!40000 ALTER TABLE `custom_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `depreciations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `months` int(11) NOT NULL,
  `depreciation_min` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `depreciations` WRITE;
/*!40000 ALTER TABLE `depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `depreciations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filesize` int(11) NOT NULL,
  `import_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `header_row` text COLLATE utf8mb4_unicode_ci,
  `first_row` text COLLATE utf8mb4_unicode_ci,
  `field_map` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `imports` WRITE;
/*!40000 ALTER TABLE `imports` DISABLE KEYS */;
INSERT INTO `imports` VALUES (1,NULL,'2022-10-21-102953-organigramme-sccomcsv',973,NULL,'2022-10-21 09:29:53','2022-10-21 09:29:53','[\"Name\",\"Parent Name\"]','[\"Section Maintenance\",\"Division Technique\"]',NULL);
/*!40000 ALTER TABLE `imports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kits` WRITE;
/*!40000 ALTER TABLE `kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `kits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kits_accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kits_accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kit_id` int(11) DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kits_accessories` WRITE;
/*!40000 ALTER TABLE `kits_accessories` DISABLE KEYS */;
/*!40000 ALTER TABLE `kits_accessories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kits_consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kits_consumables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kit_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kits_consumables` WRITE;
/*!40000 ALTER TABLE `kits_consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `kits_consumables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kits_licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kits_licenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kit_id` int(11) DEFAULT NULL,
  `license_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kits_licenses` WRITE;
/*!40000 ALTER TABLE `kits_licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `kits_licenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kits_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kits_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kit_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kits_models` WRITE;
/*!40000 ALTER TABLE `kits_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `kits_models` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `license_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `license_seats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `license_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `license_seats_license_id_index` (`license_id`),
  KEY `license_seats_assigned_to_license_id_index` (`assigned_to`,`license_id`),
  KEY `license_seats_asset_id_license_id_index` (`asset_id`,`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `license_seats` WRITE;
/*!40000 ALTER TABLE `license_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `license_seats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial` text COLLATE utf8mb4_unicode_ci,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(20,2) DEFAULT NULL,
  `order_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seats` int(11) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `depreciation_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `license_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depreciate` tinyint(1) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `termination_date` date DEFAULT NULL,
  `maintained` tinyint(1) DEFAULT NULL,
  `reassignable` tinyint(1) NOT NULL DEFAULT '1',
  `company_id` int(10) unsigned DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `licenses_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `licenses` WRITE;
/*!40000 ALTER TABLE `licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `licenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_ou` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1066 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'CIE AGADIR',NULL,NULL,NULL,'2022-10-17 18:16:09','2022-10-17 18:48:11',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(2,'CIE TAROUDANT',NULL,NULL,NULL,'2022-10-17 18:16:09','2022-10-17 18:48:13',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(3,'CIE AIR AGADIR',NULL,NULL,NULL,'2022-10-17 18:16:09','2022-10-17 18:48:15',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(4,'CIE MARITIME AGADIR',NULL,NULL,NULL,'2022-10-17 18:16:09','2022-10-17 18:48:15',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(5,'CIE TIZNIT',NULL,NULL,NULL,'2022-10-17 18:16:09','2022-10-17 18:48:16',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(6,'CIE INEZGANE',NULL,NULL,NULL,'2022-10-17 18:16:10','2022-10-17 18:48:17',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(7,'CIE TATA',NULL,NULL,NULL,'2022-10-17 18:16:10','2022-10-17 18:48:18',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(8,'CIE BIOUGRA',NULL,NULL,NULL,'2022-10-17 18:16:10','2022-10-17 18:48:20',NULL,NULL,NULL,NULL,NULL,1013,NULL,NULL,NULL,NULL),(9,'CIE AL HOCEIMA',NULL,NULL,NULL,'2022-10-17 18:16:10','2022-10-17 18:48:22',NULL,NULL,NULL,NULL,NULL,1014,NULL,NULL,NULL,NULL),(10,'CIE TARGUISTE',NULL,NULL,NULL,'2022-10-17 18:16:11','2022-10-17 18:48:24',NULL,NULL,NULL,NULL,NULL,1014,NULL,NULL,NULL,NULL),(11,'CIE BENI MELLAL',NULL,NULL,NULL,'2022-10-17 18:16:11','2022-10-17 18:48:25',NULL,NULL,NULL,NULL,NULL,1015,NULL,NULL,NULL,NULL),(12,'CIE AZILAL',NULL,NULL,NULL,'2022-10-17 18:16:11','2022-10-17 18:48:28',NULL,NULL,NULL,NULL,NULL,1015,NULL,NULL,NULL,NULL),(13,'CIE FQUIH BEN SALAH',NULL,NULL,NULL,'2022-10-17 18:16:12','2022-10-17 18:48:32',NULL,NULL,NULL,NULL,NULL,1015,NULL,NULL,NULL,NULL),(14,'CIE BOUARFA',NULL,NULL,NULL,'2022-10-17 18:16:12','2022-10-17 18:48:34',NULL,NULL,NULL,NULL,NULL,1016,NULL,NULL,NULL,NULL),(15,'CIE FIGUIG',NULL,NULL,NULL,'2022-10-17 18:16:12','2022-10-17 18:48:35',NULL,NULL,NULL,NULL,NULL,1016,NULL,NULL,NULL,NULL),(16,'CIE CASABLANCA',NULL,NULL,NULL,'2022-10-17 18:16:12','2022-10-17 18:48:36',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(17,'CIE MOHAMMEDIA',NULL,NULL,NULL,'2022-10-17 18:16:13','2022-10-17 18:48:37',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(18,'CIE NOUACEUR',NULL,NULL,NULL,'2022-10-17 18:16:13','2022-10-17 18:48:39',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(19,'CIE AIN SEBAA',NULL,NULL,NULL,'2022-10-17 18:16:13','2022-10-17 18:48:41',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(20,'CIE MARITIME CASABLANCA',NULL,NULL,NULL,'2022-10-17 18:16:13','2022-10-17 18:48:42',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(21,'CIE AIR NOUACEUR',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:43',NULL,NULL,NULL,NULL,NULL,1017,NULL,NULL,NULL,NULL),(22,'CIE DAKHLA',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:44',NULL,NULL,NULL,NULL,NULL,1018,NULL,NULL,NULL,NULL),(23,'CIE AOUSSERD',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:46',NULL,NULL,NULL,NULL,NULL,1018,NULL,NULL,NULL,NULL),(24,'CIE EL JADIDA',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:46',NULL,NULL,NULL,NULL,NULL,1019,NULL,NULL,NULL,NULL),(25,'CIE MARITIME JORF LASFAR',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:49',NULL,NULL,NULL,NULL,NULL,1019,NULL,NULL,NULL,NULL),(26,'CIE SIDI BENNOUR',NULL,NULL,NULL,'2022-10-17 18:16:14','2022-10-17 18:48:49',NULL,NULL,NULL,NULL,NULL,1019,NULL,NULL,NULL,NULL),(27,'CIE ERRACHIDIA',NULL,NULL,NULL,'2022-10-17 18:16:15','2022-10-17 18:48:52',NULL,NULL,NULL,NULL,NULL,1020,NULL,NULL,NULL,NULL),(28,'CIE MARZOUGA',NULL,NULL,NULL,'2022-10-17 18:16:15','2022-10-17 18:48:54',NULL,NULL,NULL,NULL,NULL,1020,NULL,NULL,NULL,NULL),(29,'CIE ARFOUD',NULL,NULL,NULL,'2022-10-17 18:16:15','2022-10-17 18:48:55',NULL,NULL,NULL,NULL,NULL,1020,NULL,NULL,NULL,NULL),(30,'CIE MIDELT',NULL,NULL,NULL,'2022-10-17 18:16:15','2022-10-17 18:48:57',NULL,NULL,NULL,NULL,NULL,1020,NULL,NULL,NULL,NULL),(31,'CIE ESSAOUIRA',NULL,NULL,NULL,'2022-10-17 18:16:16','2022-10-17 18:48:59',NULL,NULL,NULL,NULL,NULL,1021,NULL,NULL,NULL,NULL),(32,'CIE TAMANAR',NULL,NULL,NULL,'2022-10-17 18:16:16','2022-10-17 18:49:01',NULL,NULL,NULL,NULL,NULL,1021,NULL,NULL,NULL,NULL),(33,'CIE FES',NULL,NULL,NULL,'2022-10-17 18:16:16','2022-10-17 18:49:01',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(34,'CIE SEFROU',NULL,NULL,NULL,'2022-10-17 18:16:17','2022-10-17 18:49:03',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(35,'CIE KARIAT BA MOHAMED',NULL,NULL,NULL,'2022-10-17 18:16:17','2022-10-17 18:49:05',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(36,'CIE AIR FES SAISS',NULL,NULL,NULL,'2022-10-17 18:16:17','2022-10-17 18:49:07',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(37,'CIE TAOUNATE',NULL,NULL,NULL,'2022-10-17 18:16:17','2022-10-17 18:49:07',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(38,'CIE MISSOUR',NULL,NULL,NULL,'2022-10-17 18:16:18','2022-10-17 18:49:09',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(39,'CIE MOULAY YACOUB',NULL,NULL,NULL,'2022-10-17 18:16:18','2022-10-17 18:49:11',NULL,NULL,NULL,NULL,NULL,1022,NULL,NULL,NULL,NULL),(40,'CIE GUELMIM',NULL,NULL,NULL,'2022-10-17 18:16:18','2022-10-17 18:49:13',NULL,NULL,NULL,NULL,NULL,1023,NULL,NULL,NULL,NULL),(41,'CIE TAN-TAN',NULL,NULL,NULL,'2022-10-17 18:16:18','2022-10-17 18:49:15',NULL,NULL,NULL,NULL,NULL,1023,NULL,NULL,NULL,NULL),(42,'CIE SIDI IFNI',NULL,NULL,NULL,'2022-10-17 18:16:19','2022-10-17 18:49:17',NULL,NULL,NULL,NULL,NULL,1023,NULL,NULL,NULL,NULL),(43,'CIE ASSA-ZAG',NULL,NULL,NULL,'2022-10-17 18:16:19','2022-10-17 18:49:19',NULL,NULL,NULL,NULL,NULL,1023,NULL,NULL,NULL,NULL),(44,'CIE KENITRA',NULL,NULL,NULL,'2022-10-17 18:16:19','2022-10-17 18:49:20',NULL,NULL,NULL,NULL,NULL,1024,NULL,NULL,NULL,NULL),(45,'CIE SOUK EL ARBA DU GHARB',NULL,NULL,NULL,'2022-10-17 18:16:19','2022-10-17 18:49:22',NULL,NULL,NULL,NULL,NULL,1024,NULL,NULL,NULL,NULL),(46,'CIE AIR KENITRA',NULL,NULL,NULL,'2022-10-17 18:16:20','2022-10-17 18:49:25',NULL,NULL,NULL,NULL,NULL,1024,NULL,NULL,NULL,NULL),(47,'CIE KHEMISSET',NULL,NULL,NULL,'2022-10-17 18:16:20','2022-10-17 18:49:25',NULL,NULL,NULL,NULL,NULL,1025,NULL,NULL,NULL,NULL),(48,'CIE OULMES',NULL,NULL,NULL,'2022-10-17 18:16:20','2022-10-17 18:49:28',NULL,NULL,NULL,NULL,NULL,1025,NULL,NULL,NULL,NULL),(49,'CIE ROMMANI',NULL,NULL,NULL,'2022-10-17 18:16:20','2022-10-17 18:49:29',NULL,NULL,NULL,NULL,NULL,1025,NULL,NULL,NULL,NULL),(50,'CIE KHENIFRA',NULL,NULL,NULL,'2022-10-17 18:16:20','2022-10-17 18:49:31',NULL,NULL,NULL,NULL,NULL,1026,NULL,NULL,NULL,NULL),(51,'CIE AIT ISHAQ',NULL,NULL,NULL,'2022-10-17 18:16:21','2022-10-17 18:49:32',NULL,NULL,NULL,NULL,NULL,1026,NULL,NULL,NULL,NULL),(52,'CIE KHOURIBGA',NULL,NULL,NULL,'2022-10-17 18:16:21','2022-10-17 18:49:33',NULL,NULL,NULL,NULL,NULL,1027,NULL,NULL,NULL,NULL),(53,'CIE OUED ZEM',NULL,NULL,NULL,'2022-10-17 18:16:21','2022-10-17 18:49:35',NULL,NULL,NULL,NULL,NULL,1027,NULL,NULL,NULL,NULL),(54,'CIE LAAYOUNE',NULL,NULL,NULL,'2022-10-17 18:16:22','2022-10-17 18:49:37',NULL,NULL,NULL,NULL,NULL,1028,NULL,NULL,NULL,NULL),(55,'CIE ES-SMARA',NULL,NULL,NULL,'2022-10-17 18:16:22','2022-10-17 18:49:39',NULL,NULL,NULL,NULL,NULL,1028,NULL,NULL,NULL,NULL),(56,'CIE BOUJDOUR',NULL,NULL,NULL,'2022-10-17 18:16:22','2022-10-17 18:49:39',NULL,NULL,NULL,NULL,NULL,1028,NULL,NULL,NULL,NULL),(57,'CIE TARFAYA',NULL,NULL,NULL,'2022-10-17 18:16:22','2022-10-17 18:49:40',NULL,NULL,NULL,NULL,NULL,1028,NULL,NULL,NULL,NULL),(58,'CIE MARRAKECH',NULL,NULL,NULL,'2022-10-17 18:16:23','2022-10-17 18:49:40',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(59,'CIE TAHANNAOUT',NULL,NULL,NULL,'2022-10-17 18:16:23','2022-10-17 18:49:42',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(60,'CIE CHICHAOUA',NULL,NULL,NULL,'2022-10-17 18:16:24','2022-10-17 18:49:44',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(61,'CIE EL KALAA SRAGHNA',NULL,NULL,NULL,'2022-10-17 18:16:24','2022-10-17 18:49:46',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(62,'CIE BENGUERIR',NULL,NULL,NULL,'2022-10-17 18:16:24','2022-10-17 18:49:48',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(63,'CIE AIR MARRAKECH',NULL,NULL,NULL,'2022-10-17 18:16:25','2022-10-17 18:49:50',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(64,'CIE AIR BASE MI. BENGUERIR',NULL,NULL,NULL,'2022-10-17 18:16:25','2022-10-17 18:49:51',NULL,NULL,NULL,NULL,NULL,1029,NULL,NULL,NULL,NULL),(65,'CIE MEKNES',NULL,NULL,NULL,'2022-10-17 18:16:25','2022-10-17 18:49:52',NULL,NULL,NULL,NULL,NULL,1030,NULL,NULL,NULL,NULL),(66,'CIE EL HAJEB',NULL,NULL,NULL,'2022-10-17 18:16:25','2022-10-17 18:49:54',NULL,NULL,NULL,NULL,NULL,1030,NULL,NULL,NULL,NULL),(67,'CIE AZROU',NULL,NULL,NULL,'2022-10-17 18:16:26','2022-10-17 18:49:56',NULL,NULL,NULL,NULL,NULL,1030,NULL,NULL,NULL,NULL),(68,'CIE IFRANE',NULL,NULL,NULL,'2022-10-17 18:16:26','2022-10-17 18:49:58',NULL,NULL,NULL,NULL,NULL,1030,NULL,NULL,NULL,NULL),(69,'CIE NADOR',NULL,NULL,NULL,'2022-10-17 18:16:26','2022-10-17 18:49:59',NULL,NULL,NULL,NULL,NULL,1031,NULL,NULL,NULL,NULL),(70,'CIE ZAIOU',NULL,NULL,NULL,'2022-10-17 18:16:26','2022-10-17 18:50:01',NULL,NULL,NULL,NULL,NULL,1031,NULL,NULL,NULL,NULL),(71,'CIE AZIB MIDAR',NULL,NULL,NULL,'2022-10-17 18:16:27','2022-10-17 18:50:03',NULL,NULL,NULL,NULL,NULL,1031,NULL,NULL,NULL,NULL),(72,'C.G.T.A NADOR - AL AAROUI',NULL,NULL,'MA','2022-10-17 18:16:27','2022-10-17 18:55:55',NULL,NULL,NULL,NULL,'2022-10-17 18:55:55',1031,NULL,NULL,NULL,NULL),(73,'CIE OUARZAZATE',NULL,NULL,NULL,'2022-10-17 18:16:27','2022-10-17 18:50:06',NULL,NULL,NULL,NULL,NULL,1032,NULL,NULL,NULL,NULL),(74,'CIE TINGHIR',NULL,NULL,NULL,'2022-10-17 18:16:27','2022-10-17 18:50:08',NULL,NULL,NULL,NULL,NULL,1032,NULL,NULL,NULL,NULL),(75,'CIE ZAGORA',NULL,NULL,NULL,'2022-10-17 18:16:27','2022-10-17 18:50:09',NULL,NULL,NULL,NULL,NULL,1032,NULL,NULL,NULL,NULL),(76,'CIE OUJDA',NULL,NULL,NULL,'2022-10-17 18:16:28','2022-10-17 18:50:11',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(77,'CIE TAOURIRT',NULL,NULL,NULL,'2022-10-17 18:16:28','2022-10-17 18:50:12',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(78,'C.G.T.A OUJDA',NULL,NULL,NULL,'2022-10-17 18:16:28','2022-10-17 18:50:13',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(79,'CIE BERKANE',NULL,NULL,NULL,'2022-10-17 18:16:28','2022-10-17 18:50:13',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(80,'CIE JERADA',NULL,NULL,NULL,'2022-10-17 18:16:28','2022-10-17 18:50:15',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(81,'CIE GUERCIF',NULL,NULL,NULL,'2022-10-17 18:16:29','2022-10-17 18:50:16',NULL,NULL,NULL,NULL,NULL,1033,NULL,NULL,NULL,NULL),(82,'CIE RABAT',NULL,NULL,NULL,'2022-10-17 18:16:29','2022-10-17 18:50:18',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(83,'CIE SALE',NULL,NULL,NULL,'2022-10-17 18:16:29','2022-10-17 18:50:19',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(84,'CIE AIN EL AOUDA',NULL,NULL,NULL,'2022-10-17 18:16:29','2022-10-17 18:50:21',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(85,'CIE TEMARA',NULL,NULL,NULL,'2022-10-17 18:16:29','2022-10-17 18:50:22',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(86,'CIE SKHIRATE',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:24',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(87,'CIE AIR SALE',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:25',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(88,'C.G.T.A SALE',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:25',NULL,NULL,NULL,NULL,NULL,1034,NULL,NULL,NULL,NULL),(89,'CIE SAFI',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:25',NULL,NULL,NULL,NULL,NULL,1035,NULL,NULL,NULL,NULL),(90,'CIE YOUSSOUFIA',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:27',NULL,NULL,NULL,NULL,NULL,1035,NULL,NULL,NULL,NULL),(91,'CIE SETTAT',NULL,NULL,NULL,'2022-10-17 18:16:30','2022-10-17 18:50:29',NULL,NULL,NULL,NULL,NULL,1036,NULL,NULL,NULL,NULL),(92,'CIE BERRECHID',NULL,NULL,NULL,'2022-10-17 18:16:31','2022-10-17 18:50:31',NULL,NULL,NULL,NULL,NULL,1036,NULL,NULL,NULL,NULL),(93,'CIE BENSLIMANE',NULL,NULL,NULL,'2022-10-17 18:16:31','2022-10-17 18:50:34',NULL,NULL,NULL,NULL,NULL,1036,NULL,NULL,NULL,NULL),(94,'CIE BOUZNIKA',NULL,NULL,NULL,'2022-10-17 18:16:31','2022-10-17 18:50:35',NULL,NULL,NULL,NULL,NULL,1036,NULL,NULL,NULL,NULL),(95,'CIE MUN BENSLIMANE',NULL,NULL,NULL,'2022-10-17 18:16:31','2022-10-17 18:50:37',NULL,NULL,NULL,NULL,NULL,1036,NULL,NULL,NULL,NULL),(96,'CIE SIDI KACEM',NULL,NULL,NULL,'2022-10-17 18:16:32','2022-10-17 18:50:38',NULL,NULL,NULL,NULL,NULL,1037,NULL,NULL,NULL,NULL),(97,'CIE AIR SIDI SLIMANE',NULL,NULL,NULL,'2022-10-17 18:16:32','2022-10-17 18:50:41',NULL,NULL,NULL,NULL,NULL,1037,NULL,NULL,NULL,NULL),(98,'CIE SIDI SLIMANE',NULL,NULL,NULL,'2022-10-17 18:16:32','2022-10-17 18:50:41',NULL,NULL,NULL,NULL,NULL,1037,NULL,NULL,NULL,NULL),(99,'CIE TAZA',NULL,NULL,NULL,'2022-10-17 18:16:32','2022-10-17 18:50:42',NULL,NULL,NULL,NULL,NULL,1038,NULL,NULL,NULL,NULL),(100,'CIE OUED AMLIL',NULL,NULL,NULL,'2022-10-17 18:16:32','2022-10-17 18:50:44',NULL,NULL,NULL,NULL,NULL,1038,NULL,NULL,NULL,NULL),(101,'CIE AKNOUL',NULL,NULL,NULL,'2022-10-17 18:16:33','2022-10-17 18:50:45',NULL,NULL,NULL,NULL,NULL,1038,NULL,NULL,NULL,NULL),(102,'CIE TETOUAN',NULL,NULL,NULL,'2022-10-17 18:16:33','2022-10-17 18:50:46',NULL,NULL,NULL,NULL,NULL,1039,NULL,NULL,NULL,NULL),(103,'CIE OUAZZANE',NULL,NULL,NULL,'2022-10-17 18:16:33','2022-10-17 18:50:47',NULL,NULL,NULL,NULL,NULL,1039,NULL,NULL,NULL,NULL),(104,'CIE CHAOUEN',NULL,NULL,NULL,'2022-10-17 18:16:34','2022-10-17 18:50:49',NULL,NULL,NULL,NULL,NULL,1039,NULL,NULL,NULL,NULL),(105,'CIE TANGER',NULL,NULL,NULL,'2022-10-17 18:16:34','2022-10-17 18:50:50',NULL,NULL,NULL,NULL,NULL,1040,NULL,NULL,NULL,NULL),(106,'CIE MARITIME TANGER',NULL,NULL,NULL,'2022-10-17 18:16:35','2022-10-17 18:50:53',NULL,NULL,NULL,NULL,NULL,1040,NULL,NULL,NULL,NULL),(107,'CIE LARACHE',NULL,NULL,NULL,'2022-10-17 18:16:35','2022-10-17 18:50:54',NULL,NULL,NULL,NULL,NULL,1040,NULL,NULL,NULL,NULL),(108,'CIE MARITIME TANGER MED',NULL,NULL,NULL,'2022-10-17 18:16:35','2022-10-17 18:50:56',NULL,NULL,NULL,NULL,NULL,1040,NULL,NULL,NULL,NULL),(109,'PM AGADIR',NULL,NULL,'MA','2022-10-17 18:16:35','2022-10-17 18:16:35',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(110,'PMA AMSKROUD',NULL,NULL,'MA','2022-10-17 18:16:35','2022-10-17 18:16:35',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(111,'BJ AGADIR',NULL,NULL,'MA','2022-10-17 18:16:35','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(112,'BD AGADIR',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(113,'BT AGADIR',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(114,'BT TAMRI',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(115,'BT TAGHAZOUT',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(116,'BT IMOUZER IDA OU TANANE',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:36',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(117,'BT DRARGA',NULL,NULL,'MA','2022-10-17 18:16:36','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(118,'BT AMSKROUD',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,1,'MAD',NULL,NULL,NULL),(119,'PM TAROUDANT',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(120,'PMA ARGANA',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(121,'BJ TAROUDANT',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(122,'BD TAROUDANT',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:37',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(123,'BT TAROUDANT',NULL,NULL,'MA','2022-10-17 18:16:37','2022-10-17 18:16:38',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(124,'BT OULED TAIMA',NULL,NULL,'MA','2022-10-17 18:16:38','2022-10-17 18:16:38',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(125,'BT TAMZAOURT',NULL,NULL,'MA','2022-10-17 18:16:38','2022-10-17 18:16:38',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(126,'BT OULED BERHIL',NULL,NULL,'MA','2022-10-17 18:16:38','2022-10-17 18:16:39',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(127,'BT IGHREM',NULL,NULL,'MA','2022-10-17 18:16:39','2022-10-17 18:16:39',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(128,'BT TALIOUINE',NULL,NULL,'MA','2022-10-17 18:16:39','2022-10-17 18:16:39',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(129,'BT SEBT EL GUERDANE',NULL,NULL,'MA','2022-10-17 18:16:39','2022-10-17 18:16:39',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(130,'BT AOULOUZ',NULL,NULL,'MA','2022-10-17 18:16:39','2022-10-17 18:16:40',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(131,'BT AIT ABDELAH',NULL,NULL,'MA','2022-10-17 18:16:40','2022-10-17 18:16:40',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(132,'BT AIT IAAZA',NULL,NULL,'MA','2022-10-17 18:16:40','2022-10-17 18:16:40',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(133,'BT TAFINGOULT',NULL,NULL,'MA','2022-10-17 18:16:40','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,2,'MAD',NULL,NULL,NULL),(134,'BGTA AGADIR',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,3,'MAD',NULL,NULL,NULL),(135,'BD AIR AGADIR',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,3,'MAD',NULL,NULL,NULL),(136,'BM AGADIR',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,4,'MAD',NULL,NULL,NULL),(137,'PM TIZNIT',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(138,'BJ TIZNIT',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(139,'BD TIZNIT',NULL,NULL,'MA','2022-10-17 18:16:41','2022-10-17 18:16:41',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(140,'BT TIZNIT',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(141,'BT ANZI',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(142,'BT TAFRAOUT',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(143,'BT IDA OUGOUGMAR',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(144,'BT AGLOU',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(145,'PSP AFELA IGHIR',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:42',NULL,NULL,NULL,NULL,NULL,5,'MAD',NULL,NULL,NULL),(146,'PM INEZGANE',NULL,NULL,'MA','2022-10-17 18:16:42','2022-10-17 18:16:43',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(147,'BJ INEZGANE',NULL,NULL,'MA','2022-10-17 18:16:43','2022-10-17 18:16:43',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(148,'BD INEZGANE',NULL,NULL,'MA','2022-10-17 18:16:43','2022-10-17 18:16:43',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(149,'BT INEZGANE',NULL,NULL,'MA','2022-10-17 18:16:43','2022-10-17 18:16:43',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(150,'BT TEMSIA',NULL,NULL,'MA','2022-10-17 18:16:43','2022-10-17 18:16:44',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(151,'BT EL KOLEA',NULL,NULL,'MA','2022-10-17 18:16:44','2022-10-17 18:16:44',NULL,NULL,NULL,NULL,NULL,6,'MAD',NULL,NULL,NULL),(152,'BJ TATA',NULL,NULL,'MA','2022-10-17 18:16:44','2022-10-17 18:16:44',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(153,'BD TATA',NULL,NULL,'MA','2022-10-17 18:16:44','2022-10-17 18:16:44',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(154,'BT TATA',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(155,'BT FOUM EL HISN',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(156,'BT FOUM ZGUID',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(157,'BT TISSINT',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(158,'BT AKKA',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(159,'PSP AERODROME CIVIL',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,7,'MAD',NULL,NULL,NULL),(160,'PM BIOUGRA',NULL,NULL,'MA','2022-10-17 18:16:45','2022-10-17 18:16:45',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(161,'BJ BIOUGRA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:46',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(162,'BD BIOUGRA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:46',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(163,'BT BIOUGRA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:46',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(164,'BT AIT BAHA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:46',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(165,'BT MASSA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:46',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(166,'BT HAD BELFAA',NULL,NULL,'MA','2022-10-17 18:16:46','2022-10-17 18:16:47',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(167,'BT AIT AMIRA',NULL,NULL,'MA','2022-10-17 18:16:47','2022-10-17 18:16:47',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(168,'BT SIDI BIBI',NULL,NULL,'MA','2022-10-17 18:16:47','2022-10-17 18:16:47',NULL,NULL,NULL,NULL,NULL,8,'MAD',NULL,NULL,NULL),(169,'PM AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:47','2022-10-17 18:16:47',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(170,'BM AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:47','2022-10-17 18:16:48',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(171,'BJ AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:48','2022-10-17 18:16:48',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(172,'BD AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:48','2022-10-17 18:16:48',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(173,'BT AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:48','2022-10-17 18:16:48',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(174,'BT OUED NEKKOUR',NULL,NULL,'MA','2022-10-17 18:16:48','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(175,'BT IMZOUREN',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(176,'BT IZEMOUREN',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(177,'BT IMRABTEN',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(178,'BGTA AL HOCEIMA',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,9,'MAD',NULL,NULL,NULL),(179,'PM TARGUISTE',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(180,'BJ TARGUISTE',NULL,NULL,'MA','2022-10-17 18:16:49','2022-10-17 18:16:49',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(181,'BD TARGUISTE',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:50',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(182,'BT TARGUISTE',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:50',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(183,'BT BENI BOUFRAH',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:50',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(184,'BT KETTAMA',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:50',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(185,'BT BENI HADIFA',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:50',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(186,'BT BNI AMMART',NULL,NULL,'MA','2022-10-17 18:16:50','2022-10-17 18:16:51',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(187,'BT BNI GMIL',NULL,NULL,'MA','2022-10-17 18:16:51','2022-10-17 18:16:51',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(188,'BT IKAOUEN',NULL,NULL,'MA','2022-10-17 18:16:51','2022-10-17 18:16:51',NULL,NULL,NULL,NULL,NULL,10,'MAD',NULL,NULL,NULL),(189,'PM BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:51','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(190,'PMA BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:52','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(191,'BJ BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:52','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(192,'BD BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:52','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(193,'BT BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:52','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(194,'BT KASBA TADLA',NULL,NULL,'MA','2022-10-17 18:16:52','2022-10-17 18:16:52',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(195,'BT ZAOUIT CHEIKH',NULL,NULL,'MA','2022-10-17 18:16:53','2022-10-17 18:16:53',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(196,'BT AGHBALA',NULL,NULL,'MA','2022-10-17 18:16:53','2022-10-17 18:16:53',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(197,'BT KSIBA',NULL,NULL,'MA','2022-10-17 18:16:53','2022-10-17 18:16:54',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(198,'BT TAGZIRT',NULL,NULL,'MA','2022-10-17 18:16:54','2022-10-17 18:16:54',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(199,'BT OULED M\'BAREK',NULL,NULL,'MA','2022-10-17 18:16:54','2022-10-17 18:16:54',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(200,'BT SIDI JABER',NULL,NULL,'MA','2022-10-17 18:16:55','2022-10-17 18:16:55',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(201,'BGTA BENI MELLAL',NULL,NULL,'MA','2022-10-17 18:16:55','2022-10-17 18:16:55',NULL,NULL,NULL,NULL,NULL,11,'MAD',NULL,NULL,NULL),(202,'PM AZILAL',NULL,NULL,'MA','2022-10-17 18:16:55','2022-10-17 18:16:55',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(203,'BJ AZILAL',NULL,NULL,'MA','2022-10-17 18:16:55','2022-10-17 18:16:55',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(204,'BD AZILAL',NULL,NULL,'MA','2022-10-17 18:16:55','2022-10-17 18:16:56',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(205,'BT AZILAL',NULL,NULL,'MA','2022-10-17 18:16:56','2022-10-17 18:16:56',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(206,'BT OUAOUIZEGHT',NULL,NULL,'MA','2022-10-17 18:16:56','2022-10-17 18:16:56',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(207,'BT AFOURER',NULL,NULL,'MA','2022-10-17 18:16:56','2022-10-17 18:16:56',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(208,'BT DEMNATE',NULL,NULL,'MA','2022-10-17 18:16:56','2022-10-17 18:16:56',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(209,'BT AIT CHOUARIT',NULL,NULL,'MA','2022-10-17 18:16:56','2022-10-17 18:16:57',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(210,'BT IMADDAHAN',NULL,NULL,'MA','2022-10-17 18:16:57','2022-10-17 18:16:57',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(211,'BT TAGLEFT',NULL,NULL,'MA','2022-10-17 18:16:57','2022-10-17 18:16:57',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(212,'BT FETOUAKA',NULL,NULL,'MA','2022-10-17 18:16:57','2022-10-17 18:16:57',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(213,'BT TANANT',NULL,NULL,'MA','2022-10-17 18:16:57','2022-10-17 18:16:57',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(214,'BT TILOUGUITE',NULL,NULL,'MA','2022-10-17 18:16:57','2022-10-17 18:16:58',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(215,'BT AIT AATAB',NULL,NULL,'MA','2022-10-17 18:16:58','2022-10-17 18:16:58',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(216,'BT TABANT',NULL,NULL,'MA','2022-10-17 18:16:58','2022-10-17 18:16:58',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(217,'BT BNI A\'YAT',NULL,NULL,'MA','2022-10-17 18:16:58','2022-10-17 18:16:58',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(218,'PSP BIN EL OUIDANE',NULL,NULL,'MA','2022-10-17 18:16:58','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(219,'PSP OUZOUD',NULL,NULL,'MA','2022-10-17 18:16:59','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,12,'MAD',NULL,NULL,NULL),(220,'PM FQUIH BEN SALAH',NULL,NULL,'MA','2022-10-17 18:16:59','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(221,'BJ FQUIH BEN SALAH',NULL,NULL,'MA','2022-10-17 18:16:59','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(222,'BD FQUIH BEN SALAH',NULL,NULL,'MA','2022-10-17 18:16:59','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(223,'BT FQUIH BEN SALAH',NULL,NULL,'MA','2022-10-17 18:16:59','2022-10-17 18:16:59',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(224,'BT SOUK SEBT OULED NEMMA',NULL,NULL,'MA','2022-10-17 18:17:00','2022-10-17 18:17:00',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(225,'BT DAR OULED ZIDOUH',NULL,NULL,'MA','2022-10-17 18:17:00','2022-10-17 18:17:00',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(226,'BT SIDI AISSA',NULL,NULL,'MA','2022-10-17 18:17:00','2022-10-17 18:17:00',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(227,'BT HAD BRADIA',NULL,NULL,'MA','2022-10-17 18:17:01','2022-10-17 18:17:01',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(228,'BT OULED AYAD',NULL,NULL,'MA','2022-10-17 18:17:01','2022-10-17 18:17:01',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(229,'BT HAD BOUMOUSSA',NULL,NULL,'MA','2022-10-17 18:17:01','2022-10-17 18:17:01',NULL,NULL,NULL,NULL,NULL,13,'MAD',NULL,NULL,NULL),(230,'PM BOUARFA',NULL,NULL,'MA','2022-10-17 18:17:01','2022-10-17 18:17:01',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(231,'BJ BOUARFA',NULL,NULL,'MA','2022-10-17 18:17:01','2022-10-17 18:17:01',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(232,'BD BOUARFA',NULL,NULL,'MA','2022-10-17 18:17:02','2022-10-17 18:17:02',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(233,'BT BOUARFA',NULL,NULL,'MA','2022-10-17 18:17:02','2022-10-17 18:17:02',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(234,'BT TENDRARA',NULL,NULL,'MA','2022-10-17 18:17:02','2022-10-17 18:17:02',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(235,'BT BENI TADJITE',NULL,NULL,'MA','2022-10-17 18:17:02','2022-10-17 18:17:03',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(236,'BT TALSINT',NULL,NULL,'MA','2022-10-17 18:17:03','2022-10-17 18:17:03',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(237,'PSP EL MANGOUB',NULL,NULL,'MA','2022-10-17 18:17:03','2022-10-17 18:17:03',NULL,NULL,NULL,NULL,NULL,14,'MAD',NULL,NULL,NULL),(238,'BJ FIGUIG',NULL,NULL,'MA','2022-10-17 18:17:03','2022-10-17 18:17:03',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(239,'BD FIGUIG',NULL,NULL,'MA','2022-10-17 18:17:03','2022-10-17 18:17:03',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(240,'BT FIGUIG',NULL,NULL,'MA','2022-10-17 18:17:03','2022-10-17 18:17:04',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(241,'BT BOUANANE',NULL,NULL,'MA','2022-10-17 18:17:04','2022-10-17 18:17:04',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(242,'BT AIN CHAIR',NULL,NULL,'MA','2022-10-17 18:17:04','2022-10-17 18:17:04',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(243,'BT AIN CHOUATER',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,15,'MAD',NULL,NULL,NULL),(244,'PM CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(245,'PMA BOUSKOURA',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(246,'BJ CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(247,'BD CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(248,'BT CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:05',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(249,'BT AIN DIAB',NULL,NULL,'MA','2022-10-17 18:17:05','2022-10-17 18:17:06',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(250,'BT ERRAHMA',NULL,NULL,'MA','2022-10-17 18:17:06','2022-10-17 18:17:06',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(251,'BT DAR BOUAAZA',NULL,NULL,'MA','2022-10-17 18:17:06','2022-10-17 18:17:06',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(252,'BA AMG FAR CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:06','2022-10-17 18:17:06',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(253,'PSP BOUSKOURA',NULL,NULL,'MA','2022-10-17 18:17:06','2022-10-17 18:17:06',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(254,'PSP AIN GUEDID',NULL,NULL,'MA','2022-10-17 18:17:06','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(255,'PSP TAMARIS',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,16,'MAD',NULL,NULL,NULL),(256,'PMA MOHAMMEDIA',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(257,'BJ MOHAMMEDIA',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(258,'BD MOHAMMEDIA',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(259,'BT MOHAMMEDIA',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(260,'BT AIN HARROUDA',NULL,NULL,'MA','2022-10-17 18:17:07','2022-10-17 18:17:07',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(261,'BT BNI YAKHLEF',NULL,NULL,'MA','2022-10-17 18:17:08','2022-10-17 18:17:08',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(262,'BT ZENATA',NULL,NULL,'MA','2022-10-17 18:17:08','2022-10-17 18:17:08',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(263,'BT SIDI MOUSSA BEN ALI',NULL,NULL,'MA','2022-10-17 18:17:08','2022-10-17 18:17:08',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(264,'BGTA TIT MELLIL',NULL,NULL,'MA','2022-10-17 18:17:08','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(265,'PSP PALOMA',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,17,'MAD',NULL,NULL,NULL),(266,'PM NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(267,'BJ NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(268,'BT NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(269,'BArmt NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(270,'BT BOUSKOURA',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:09',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(271,'BT LAMKANSSA',NULL,NULL,'MA','2022-10-17 18:17:09','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(272,'BT VILLE VERTE DE BOUSKOURA',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(273,'BT OULED SALAH',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(274,'PMA NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,18,'MAD',NULL,NULL,NULL),(275,'PMA TIT MELLIL',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(276,'BJ AIN SEBAA',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:10',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(277,'BD AIN SEBAA',NULL,NULL,'MA','2022-10-17 18:17:10','2022-10-17 18:17:11',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(278,'BT AIN SEBAA',NULL,NULL,'MA','2022-10-17 18:17:11','2022-10-17 18:17:11',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(279,'BT MEDIOUNA',NULL,NULL,'MA','2022-10-17 18:17:11','2022-10-17 18:17:11',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(280,'BT TIT MELLIL',NULL,NULL,'MA','2022-10-17 18:17:12','2022-10-17 18:17:12',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(281,'BT LAHRAOUIYINE',NULL,NULL,'MA','2022-10-17 18:17:12','2022-10-17 18:17:12',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(282,'BT AL HAMD',NULL,NULL,'MA','2022-10-17 18:17:12','2022-10-17 18:17:12',NULL,NULL,NULL,NULL,NULL,19,'MAD',NULL,NULL,NULL),(283,'BM CASABLANCA',NULL,NULL,'MA','2022-10-17 18:17:12','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,20,'MAD',NULL,NULL,NULL),(284,'BM MOHAMMEDIA',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,20,'MAD',NULL,NULL,NULL),(285,'BJ Air NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,21,'MAD',NULL,NULL,NULL),(286,'BGTA NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,21,'MAD',NULL,NULL,NULL),(287,'Bde Fil et Ren NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,21,'MAD',NULL,NULL,NULL),(288,'Bde Cir NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:13',NULL,NULL,NULL,NULL,NULL,21,'MAD',NULL,NULL,NULL),(289,'Bde Sur et Prot NOUACEUR',NULL,NULL,'MA','2022-10-17 18:17:13','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,21,'MAD',NULL,NULL,NULL),(290,'BM DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:14','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(291,'PM DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:14','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(292,'BJ DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:14','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(293,'BD DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:14','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(294,'BT DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:14','2022-10-17 18:17:14',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(295,'BT AARICH',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:15',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(296,'BT EL ARGOUB',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:15',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(297,'BT IMLILI',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:15',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(298,'BGTA DAKHLA',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:15',NULL,NULL,NULL,NULL,NULL,22,'MAD',NULL,NULL,NULL),(299,'BJ AOUSSERD',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:15',NULL,NULL,NULL,NULL,NULL,23,'MAD',NULL,NULL,NULL),(300,'BD AOUSSERD',NULL,NULL,'MA','2022-10-17 18:17:15','2022-10-17 18:17:16',NULL,NULL,NULL,NULL,NULL,23,'MAD',NULL,NULL,NULL),(301,'BT AOUSSERD',NULL,NULL,'MA','2022-10-17 18:17:16','2022-10-17 18:17:16',NULL,NULL,NULL,NULL,NULL,23,'MAD',NULL,NULL,NULL),(302,'BT BIR GUENDOUZ',NULL,NULL,'MA','2022-10-17 18:17:16','2022-10-17 18:17:16',NULL,NULL,NULL,NULL,NULL,23,'MAD',NULL,NULL,NULL),(303,'PSP GUERIGRAT',NULL,NULL,'MA','2022-10-17 18:17:16','2022-10-17 18:17:16',NULL,NULL,NULL,NULL,NULL,23,'MAD',NULL,NULL,NULL),(304,'PM EL JADIDA',NULL,NULL,'MA','2022-10-17 18:17:16','2022-10-17 18:17:16',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(305,'PMA EL JADIDA',NULL,NULL,'MA','2022-10-17 18:17:16','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(306,'PMA BIR JDID',NULL,NULL,'MA','2022-10-17 18:17:17','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(307,'PMA SIDI SMAIL',NULL,NULL,'MA','2022-10-17 18:17:17','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(308,'BJ EL JADIDA',NULL,NULL,'MA','2022-10-17 18:17:17','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(309,'BD EL JADIDA',NULL,NULL,'MA','2022-10-17 18:17:17','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(310,'BT EL JADIDA',NULL,NULL,'MA','2022-10-17 18:17:17','2022-10-17 18:17:17',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(311,'BT BIR JDID',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(312,'BT AZEMOUR',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(313,'BT SIDI SMAIL',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(314,'BT HAD OULED FREJ',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(315,'BT SIDI BOUZID',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(316,'BT JEMAA OULED GHANEM',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(317,'BT KHMIS METTOUH',NULL,NULL,'MA','2022-10-17 18:17:18','2022-10-17 18:17:18',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(318,'BT CHTOUKA',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(319,'PSP HAOUZIA',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(320,'PSP MY ABDELLAH AMGHAR',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,24,'MAD',NULL,NULL,NULL),(321,'BM JORF LASFAR',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,25,'MAD',NULL,NULL,NULL),(322,'PM SIDI BENNOUR',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(323,'PMA LOUALIDIA',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(324,'BJ SIDI BENNOUR',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(325,'BD SIDI BENNOUR',NULL,NULL,'MA','2022-10-17 18:17:19','2022-10-17 18:17:19',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(326,'BT SIDI BENNOUR',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(327,'BT KHEMIS ZEMAMRA',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(328,'BT EL AOUNATE',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(329,'BT EL OUALIDIA',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(330,'BT OULAD AMRANE',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(331,'BT BNI HLAL',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(332,'BT BOUHMAME',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(333,'BT METRANE',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:20',NULL,NULL,NULL,NULL,NULL,26,'MAD',NULL,NULL,NULL),(334,'PM ERRACHIDIA',NULL,NULL,'MA','2022-10-17 18:17:20','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(335,'BJ ERRACHIDIA',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(336,'BD ERRACHIDIA',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(337,'BT ERRACHIDIA',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(338,'BT BOUDNIB',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(339,'BT AOUFOUS',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(340,'BMun ERRACHIDIA',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(341,'BGTA MOULAY ALI CHERRIF',NULL,NULL,'MA','2022-10-17 18:17:21','2022-10-17 18:17:21',NULL,NULL,NULL,NULL,NULL,27,'MAD',NULL,NULL,NULL),(342,'PM MARZOUGA',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(343,'BD MARZOUGA',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(344,'BJ MARZOUGA',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(345,'BT MARZOUGA',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(346,'BT ERRISSANI',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(347,'BT TAOUS',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:22',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(348,'BT SIDI ALI',NULL,NULL,'MA','2022-10-17 18:17:22','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,28,'MAD',NULL,NULL,NULL),(349,'BJ ARFOUD',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(350,'BD ARFOUD',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(351,'BT ARFOUD',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(352,'BT GOULMIMA',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(353,'BT JORF',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:23',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(354,'BT MELAAB',NULL,NULL,'MA','2022-10-17 18:17:23','2022-10-17 18:17:24',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(355,'BT TINJDAD',NULL,NULL,'MA','2022-10-17 18:17:24','2022-10-17 18:17:24',NULL,NULL,NULL,NULL,NULL,29,'MAD',NULL,NULL,NULL),(356,'PM MIDELT',NULL,NULL,'MA','2022-10-17 18:17:24','2022-10-17 18:17:24',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(357,'BJ MIDELT',NULL,NULL,'MA','2022-10-17 18:17:24','2022-10-17 18:17:24',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(358,'BD MIDELT',NULL,NULL,'MA','2022-10-17 18:17:24','2022-10-17 18:17:25',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(359,'BT MIDELT',NULL,NULL,'MA','2022-10-17 18:17:25','2022-10-17 18:17:25',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(360,'BT ITZER',NULL,NULL,'MA','2022-10-17 18:17:25','2022-10-17 18:17:25',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(361,'BT TOUNFITE',NULL,NULL,'MA','2022-10-17 18:17:25','2022-10-17 18:17:25',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(362,'BT BOUMIA',NULL,NULL,'MA','2022-10-17 18:17:25','2022-10-17 18:17:25',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(363,'BT IMILCHIL',NULL,NULL,'MA','2022-10-17 18:17:25','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(364,'BT ER-RICH',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(365,'BT GOURRAMA',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(366,'BT ZAIDA',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(367,'BT AMOUGUER',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,30,'MAD',NULL,NULL,NULL),(368,'PM ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(369,'BM ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:26',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(370,'BJ ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:26','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(371,'BD ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(372,'BT ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(373,'BT TALMEST',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(374,'BT TLET HANCHANE',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(375,'BT TAFTACHT',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:27',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(376,'BT AQUERMOUD',NULL,NULL,'MA','2022-10-17 18:17:27','2022-10-17 18:17:28',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(377,'BT OUNAGHA',NULL,NULL,'MA','2022-10-17 18:17:28','2022-10-17 18:17:28',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(378,'BGTA ESSAOUIRA',NULL,NULL,'MA','2022-10-17 18:17:28','2022-10-17 18:17:28',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(379,'PSP SIDI KAOUKI',NULL,NULL,'MA','2022-10-17 18:17:28','2022-10-17 18:17:28',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(380,'PSP MY BOUZERKTOUN',NULL,NULL,'MA','2022-10-17 18:17:28','2022-10-17 18:17:28',NULL,NULL,NULL,NULL,NULL,31,'MAD',NULL,NULL,NULL),(381,'PM TAMANAR',NULL,NULL,'MA','2022-10-17 18:17:28','2022-10-17 18:17:29',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(382,'BJ TAMANAR',NULL,NULL,'MA','2022-10-17 18:17:29','2022-10-17 18:17:29',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(383,'BD TAMANAR',NULL,NULL,'MA','2022-10-17 18:17:29','2022-10-17 18:17:29',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(384,'BT TAMANAR',NULL,NULL,'MA','2022-10-17 18:17:29','2022-10-17 18:17:29',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(385,'BT SMIMOU',NULL,NULL,'MA','2022-10-17 18:17:29','2022-10-17 18:17:29',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(386,'BT AIT DAOUD',NULL,NULL,'MA','2022-10-17 18:17:30','2022-10-17 18:17:30',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(387,'BT BIZDAD',NULL,NULL,'MA','2022-10-17 18:17:30','2022-10-17 18:17:30',NULL,NULL,NULL,NULL,NULL,32,'MAD',NULL,NULL,NULL),(388,'PM FES',NULL,NULL,'MA','2022-10-17 18:17:30','2022-10-17 18:17:30',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(389,'PMA FES',NULL,NULL,'MA','2022-10-17 18:17:30','2022-10-17 18:17:30',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(390,'BJ FES',NULL,NULL,'MA','2022-10-17 18:17:30','2022-10-17 18:17:30',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(391,'BD FES',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(392,'BT FES',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(393,'BT SIDI HRAZEM',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(394,'BT OULED TAYEB',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(395,'BT AIN BIDA',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,33,'MAD',NULL,NULL,NULL),(396,'PM SEFROU',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:31',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(397,'PMA SERFOU',NULL,NULL,'MA','2022-10-17 18:17:31','2022-10-17 18:17:32',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(398,'PMA RAS TABOUDA',NULL,NULL,'MA','2022-10-17 18:17:32','2022-10-17 18:17:32',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(399,'BJ SEFROU',NULL,NULL,'MA','2022-10-17 18:17:32','2022-10-17 18:17:32',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(400,'BD SEFROU',NULL,NULL,'MA','2022-10-17 18:17:32','2022-10-17 18:17:32',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(401,'BT SEFROU',NULL,NULL,'MA','2022-10-17 18:17:32','2022-10-17 18:17:33',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(402,'BT BHALIL',NULL,NULL,'MA','2022-10-17 18:17:33','2022-10-17 18:17:33',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(403,'BT EL MENZEL',NULL,NULL,'MA','2022-10-17 18:17:33','2022-10-17 18:17:33',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(404,'BT IMOUZER DU KANDAR',NULL,NULL,'MA','2022-10-17 18:17:33','2022-10-17 18:17:33',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(405,'BT BIR TAMTAM',NULL,NULL,'MA','2022-10-17 18:17:34','2022-10-17 18:17:34',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(406,'BT RIBAT EL KHAIR',NULL,NULL,'MA','2022-10-17 18:17:34','2022-10-17 18:17:34',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(407,'BT AIN CHEGGAG',NULL,NULL,'MA','2022-10-17 18:17:34','2022-10-17 18:17:34',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(408,'BT ADREJ',NULL,NULL,'MA','2022-10-17 18:17:34','2022-10-17 18:17:34',NULL,NULL,NULL,NULL,NULL,34,'MAD',NULL,NULL,NULL),(409,'PM KARIAT BA MOHAMED',NULL,NULL,'MA','2022-10-17 18:17:34','2022-10-17 18:17:35',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(410,'BJ KARIAT BA MOHAMED',NULL,NULL,'MA','2022-10-17 18:17:35','2022-10-17 18:17:35',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(411,'BD KARIAT BA MOHAMED',NULL,NULL,'MA','2022-10-17 18:17:35','2022-10-17 18:17:35',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(412,'BT KARIAT BA MOHAMED',NULL,NULL,'MA','2022-10-17 18:17:35','2022-10-17 18:17:35',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(413,'BT OURDZAGH',NULL,NULL,'MA','2022-10-17 18:17:35','2022-10-17 18:17:35',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(414,'BT RHAFSAI',NULL,NULL,'MA','2022-10-17 18:17:35','2022-10-17 18:17:36',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(415,'BT LOULJA',NULL,NULL,'MA','2022-10-17 18:17:36','2022-10-17 18:17:36',NULL,NULL,NULL,NULL,NULL,35,'MAD',NULL,NULL,NULL),(416,'BGTA FES SAISS',NULL,NULL,'MA','2022-10-17 18:17:36','2022-10-17 18:17:36',NULL,NULL,NULL,NULL,NULL,36,'MAD',NULL,NULL,NULL),(417,'BJ TAOUNATE',NULL,NULL,'MA','2022-10-17 18:17:36','2022-10-17 18:17:36',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(418,'BD TAOUNATE',NULL,NULL,'MA','2022-10-17 18:17:36','2022-10-17 18:17:36',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(419,'BT TAOUNATE',NULL,NULL,'MA','2022-10-17 18:17:36','2022-10-17 18:17:37',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(420,'BT AIN AICHA',NULL,NULL,'MA','2022-10-17 18:17:37','2022-10-17 18:17:37',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(421,'BT TISSA',NULL,NULL,'MA','2022-10-17 18:17:37','2022-10-17 18:17:37',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(422,'BT TAHAR SOUK',NULL,NULL,'MA','2022-10-17 18:17:37','2022-10-17 18:17:37',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(423,'BT BOUAROUS',NULL,NULL,'MA','2022-10-17 18:17:37','2022-10-17 18:17:37',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(424,'BT BNI OULID',NULL,NULL,'MA','2022-10-17 18:17:37','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(425,'BT OULAD RIYAB',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,37,'MAD',NULL,NULL,NULL),(426,'PM MISSOUR',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(427,'BJ MISSOUR',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(428,'BD MISSOUR',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(429,'BT MISSOUR',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:38',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(430,'BT BOULEMANE',NULL,NULL,'MA','2022-10-17 18:17:38','2022-10-17 18:17:39',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(431,'BT OUTAT EL HAJ',NULL,NULL,'MA','2022-10-17 18:17:39','2022-10-17 18:17:39',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(432,'BT IMOUZER MARMOUCHA',NULL,NULL,'MA','2022-10-17 18:17:39','2022-10-17 18:17:39',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(433,'BT TENDITE',NULL,NULL,'MA','2022-10-17 18:17:39','2022-10-17 18:17:39',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(434,'BT KSABI',NULL,NULL,'MA','2022-10-17 18:17:39','2022-10-17 18:17:40',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(435,'BT GUIGOU',NULL,NULL,'MA','2022-10-17 18:17:40','2022-10-17 18:17:40',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(436,'BT SKOURA M\'DAZ',NULL,NULL,'MA','2022-10-17 18:17:40','2022-10-17 18:17:40',NULL,NULL,NULL,NULL,NULL,38,'MAD',NULL,NULL,NULL),(437,'PM MOULAY YACOUB',NULL,NULL,'MA','2022-10-17 18:17:40','2022-10-17 18:17:40',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(438,'BJ MOULAY YACOUB',NULL,NULL,'MA','2022-10-17 18:17:40','2022-10-17 18:17:40',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(439,'BD MOULAY YACOUB',NULL,NULL,'MA','2022-10-17 18:17:40','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(440,'BT MOULAY YACOUB',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(441,'BT BEN SOUDA',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(442,'BT AIN LALLAH',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(443,'BT LAAJAJRA',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(444,'BT OULED MIMOUN',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(445,'BT RAS EL MA',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:41',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(446,'BT AIN KANSARA',NULL,NULL,'MA','2022-10-17 18:17:41','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(447,'BT AIN BOUAL',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,39,'MAD',NULL,NULL,NULL),(448,'PM GUELMIM',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(449,'BJ GUELMIM',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(450,'BD GUELMIM',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(451,'BT GUELMIM',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(452,'BT BOUIZAKAREN',NULL,NULL,'MA','2022-10-17 18:17:42','2022-10-17 18:17:42',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(453,'BT TAGHJIJT',NULL,NULL,'MA','2022-10-17 18:17:43','2022-10-17 18:17:43',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(454,'BT LAQSABI',NULL,NULL,'MA','2022-10-17 18:17:43','2022-10-17 18:17:43',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(455,'BT IFRANE ALAS SAGHIR',NULL,NULL,'MA','2022-10-17 18:17:43','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(456,'BGTA GUELMIM',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,40,'MAD',NULL,NULL,NULL),(457,'BM TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(458,'PM TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(459,'BJ TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(460,'BD TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:44',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(461,'BT TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:44','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(462,'BT TAN-TAN PLAGE',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(463,'BT TILIMZOUN',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(464,'BT ABATTIH',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(465,'BGTA TAN-TAN',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(466,'PSP OUED CHBIKA',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,41,'MAD',NULL,NULL,NULL),(467,'PM SIDI IFNI',NULL,NULL,'MA','2022-10-17 18:17:45','2022-10-17 18:17:45',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(468,'BJ SIDI IFNI',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:46',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(469,'BD SIDI IFNI',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:46',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(470,'BT SIDI IFNI',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:46',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(471,'BT TLATA LAKHSASS',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:46',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(472,'BT MIRLEFT',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:46',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(473,'BT TIGHIRT',NULL,NULL,'MA','2022-10-17 18:17:46','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,42,'MAD',NULL,NULL,NULL),(474,'PM ASSA ZAG',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,43,'MAD',NULL,NULL,NULL),(475,'BJ ASSA ZAG',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,43,'MAD',NULL,NULL,NULL),(476,'BD ASSA ZAG',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,43,'MAD',NULL,NULL,NULL),(477,'BT ASSA',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,43,'MAD',NULL,NULL,NULL),(478,'BT ZAG',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:47',NULL,NULL,NULL,NULL,NULL,43,'MAD',NULL,NULL,NULL),(479,'PM KENITRA',NULL,NULL,'MA','2022-10-17 18:17:47','2022-10-17 18:17:48',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(480,'PMA KENITRA',NULL,NULL,'MA','2022-10-17 18:17:48','2022-10-17 18:17:48',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(481,'PMA NKHAKHSA',NULL,NULL,'MA','2022-10-17 18:17:48','2022-10-17 18:17:48',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(482,'BM KENITRA',NULL,NULL,'MA','2022-10-17 18:17:48','2022-10-17 18:17:48',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(483,'BJ KENITRA',NULL,NULL,'MA','2022-10-17 18:17:48','2022-10-17 18:17:49',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(484,'BD KENITRA',NULL,NULL,'MA','2022-10-17 18:17:49','2022-10-17 18:17:49',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(485,'BT KENITRA',NULL,NULL,'MA','2022-10-17 18:17:49','2022-10-17 18:17:49',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(486,'BT SIDI ALLAL TAZI',NULL,NULL,'MA','2022-10-17 18:17:49','2022-10-17 18:17:49',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(487,'BT MEHDIA',NULL,NULL,'MA','2022-10-17 18:17:49','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(488,'BT SIDI TAIBI',NULL,NULL,'MA','2022-10-17 18:17:50','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(489,'BT BEN MANSOUR',NULL,NULL,'MA','2022-10-17 18:17:50','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,44,'MAD',NULL,NULL,NULL),(490,'PM SOUK EL ARBA DU GHARB',NULL,NULL,'MA','2022-10-17 18:17:50','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(491,'PMA MOULAY BOUSSELHAM',NULL,NULL,'MA','2022-10-17 18:17:50','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(492,'BM MOULAY BOUSSELHAM',NULL,NULL,'MA','2022-10-17 18:17:50','2022-10-17 18:17:50',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(493,'BJ SOUK EL ARBA DU GHARB',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(494,'BD SOUK EL ARBA DU GHARB',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(495,'BT SOUK EL ARBA DU GHARB',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(496,'BT MOULAY BOUSSELHAM',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(497,'BT ARBAOUA',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(498,'BT LALLA MIMOUNA',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:51',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(499,'BT SIDI MOHAMED LAHMAR',NULL,NULL,'MA','2022-10-17 18:17:51','2022-10-17 18:17:52',NULL,NULL,NULL,NULL,NULL,45,'MAD',NULL,NULL,NULL),(500,'BA KENITRA',NULL,NULL,'MA','2022-10-17 18:17:52','2022-10-17 18:17:52',NULL,NULL,NULL,NULL,NULL,46,'MAD',NULL,NULL,NULL),(501,'BMun KENITRA',NULL,NULL,'MA','2022-10-17 18:17:52','2022-10-17 18:17:52',NULL,NULL,NULL,NULL,NULL,46,'MAD',NULL,NULL,NULL),(502,'PM KHEMISSET',NULL,NULL,'MA','2022-10-17 18:17:52','2022-10-17 18:17:52',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(503,'PMA KHEMISSET',NULL,NULL,'MA','2022-10-17 18:17:52','2022-10-17 18:17:52',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(504,'PMA TIFLET',NULL,NULL,'MA','2022-10-17 18:17:52','2022-10-17 18:17:53',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(505,'PMA BAHRAOUI',NULL,NULL,'MA','2022-10-17 18:17:53','2022-10-17 18:17:53',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(506,'BJ KHEMISSET',NULL,NULL,'MA','2022-10-17 18:17:53','2022-10-17 18:17:53',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(507,'BD KHEMISSET',NULL,NULL,'MA','2022-10-17 18:17:53','2022-10-17 18:17:53',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(508,'BT KHEMISSET',NULL,NULL,'MA','2022-10-17 18:17:53','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(509,'BT AIT SIBERNE',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(510,'BT TIFLET',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(511,'BT SIDI ALLAL BAHRAOUI',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(512,'BT AIT YADINE',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(513,'BT SIDI ABDERRAZAK',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:54',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(514,'BT AIT OURIBEL',NULL,NULL,'MA','2022-10-17 18:17:54','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,47,'MAD',NULL,NULL,NULL),(515,'PM OULMES',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(516,'BJ OULMES',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(517,'BD OULMES',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(518,'BT OULMES',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(519,'BT MAAZIZ',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:55',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(520,'BT TIDAS',NULL,NULL,'MA','2022-10-17 18:17:55','2022-10-17 18:17:56',NULL,NULL,NULL,NULL,NULL,48,'MAD',NULL,NULL,NULL),(521,'BJ ROMMANI',NULL,NULL,'MA','2022-10-17 18:17:56','2022-10-17 18:17:56',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(522,'BD ROMMANI',NULL,NULL,'MA','2022-10-17 18:17:56','2022-10-17 18:17:56',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(523,'BT ROMMANI',NULL,NULL,'MA','2022-10-17 18:17:56','2022-10-17 18:17:56',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(524,'BT HAD BRACHOUA',NULL,NULL,'MA','2022-10-17 18:17:57','2022-10-17 18:17:57',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(525,'BT ZHILIGA',NULL,NULL,'MA','2022-10-17 18:17:57','2022-10-17 18:17:57',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(526,'BT HAD LAGHOUALEM',NULL,NULL,'MA','2022-10-17 18:17:57','2022-10-17 18:17:57',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(527,'BT AIN SBIT',NULL,NULL,'MA','2022-10-17 18:17:57','2022-10-17 18:17:57',NULL,NULL,NULL,NULL,NULL,49,'MAD',NULL,NULL,NULL),(528,'PM KHENIFRA',NULL,NULL,'MA','2022-10-17 18:17:58','2022-10-17 18:17:58',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(529,'BJ KHENIFRA',NULL,NULL,'MA','2022-10-17 18:17:58','2022-10-17 18:17:58',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(530,'BD KHENIFRA',NULL,NULL,'MA','2022-10-17 18:17:58','2022-10-17 18:17:58',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(531,'BT KHENIFRA',NULL,NULL,'MA','2022-10-17 18:17:58','2022-10-17 18:17:59',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(532,'BT MRIRT',NULL,NULL,'MA','2022-10-17 18:17:59','2022-10-17 18:17:59',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(533,'BT AGUELMOUSS',NULL,NULL,'MA','2022-10-17 18:17:59','2022-10-17 18:17:59',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(534,'BT MOULAY BOUAZZA',NULL,NULL,'MA','2022-10-17 18:17:59','2022-10-17 18:17:59',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(535,'BT KAF NSOUR',NULL,NULL,'MA','2022-10-17 18:17:59','2022-10-17 18:17:59',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(536,'BT EL HAMMAM',NULL,NULL,'MA','2022-10-17 18:17:59','2022-10-17 18:18:00',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(537,'BT AGUELMAM AZEGZA',NULL,NULL,'MA','2022-10-17 18:18:00','2022-10-17 18:18:00',NULL,NULL,NULL,NULL,NULL,50,'MAD',NULL,NULL,NULL),(538,'PM AIT ISHAQ',NULL,NULL,'MA','2022-10-17 18:18:00','2022-10-17 18:18:00',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(539,'BJ AIT ISHAQ',NULL,NULL,'MA','2022-10-17 18:18:00','2022-10-17 18:18:00',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(540,'BD AIT ISHAQ',NULL,NULL,'MA','2022-10-17 18:18:00','2022-10-17 18:18:00',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(541,'BT AIT ISHAQ',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:01',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(542,'BT KERROUCHEN',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:01',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(543,'BT TIGHASSALINE',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:01',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(544,'BT EL KBAB',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:01',NULL,NULL,NULL,NULL,NULL,51,'MAD',NULL,NULL,NULL),(545,'PM KHOURIBGA',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:01',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(546,'PMA KHOURIBGA',NULL,NULL,'MA','2022-10-17 18:18:01','2022-10-17 18:18:02',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(547,'BJ KHOURIBGA',NULL,NULL,'MA','2022-10-17 18:18:02','2022-10-17 18:18:02',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(548,'BD KHOURIBGA',NULL,NULL,'MA','2022-10-17 18:18:02','2022-10-17 18:18:02',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(549,'BT KHOURIBGA',NULL,NULL,'MA','2022-10-17 18:18:02','2022-10-17 18:18:02',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(550,'BT BOUJNIBA',NULL,NULL,'MA','2022-10-17 18:18:02','2022-10-17 18:18:02',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(551,'BT HATTANE',NULL,NULL,'MA','2022-10-17 18:18:02','2022-10-17 18:18:03',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(552,'BT BOULANOUARE',NULL,NULL,'MA','2022-10-17 18:18:03','2022-10-17 18:18:03',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(553,'BT LAGFAF-BNI YKHLEF',NULL,NULL,'MA','2022-10-17 18:18:03','2022-10-17 18:18:03',NULL,NULL,NULL,NULL,NULL,52,'MAD',NULL,NULL,NULL),(554,'PM OUED ZEM',NULL,NULL,'MA','2022-10-17 18:18:03','2022-10-17 18:18:03',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(555,'PMA OUED ZEM',NULL,NULL,'MA','2022-10-17 18:18:03','2022-10-17 18:18:03',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(556,'BJ OUED ZEM',NULL,NULL,'MA','2022-10-17 18:18:03','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(557,'BD OUED ZEM',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(558,'BT OUED ZEM',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(559,'BT BENI BATAOU',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(560,'BT BEJAAD',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(561,'BT OULED BOUGHADI',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:04',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(562,'BT CHOUGRANE',NULL,NULL,'MA','2022-10-17 18:18:04','2022-10-17 18:18:05',NULL,NULL,NULL,NULL,NULL,53,'MAD',NULL,NULL,NULL),(563,'PM LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:05','2022-10-17 18:18:05',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(564,'BM LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:05','2022-10-17 18:18:05',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(565,'BJ LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:05','2022-10-17 18:18:05',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(566,'BD LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:05','2022-10-17 18:18:06',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(567,'BT LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:06','2022-10-17 18:18:06',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(568,'BT BOUCRAA',NULL,NULL,'MA','2022-10-17 18:18:06','2022-10-17 18:18:06',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(569,'BT FOUM EL OUAD',NULL,NULL,'MA','2022-10-17 18:18:06','2022-10-17 18:18:06',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(570,'BT PORT LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:06','2022-10-17 18:18:06',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(571,'BGTA LAAYOUNE',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:07',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(572,'PSP FOUM LOUED',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:07',NULL,NULL,NULL,NULL,NULL,54,'MAD',NULL,NULL,NULL),(573,'BJ ES-SMARA',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:07',NULL,NULL,NULL,NULL,NULL,55,'MAD',NULL,NULL,NULL),(574,'BD ES-SMARA',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:07',NULL,NULL,NULL,NULL,NULL,55,'MAD',NULL,NULL,NULL),(575,'BT ES-SMARA',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:07',NULL,NULL,NULL,NULL,NULL,55,'MAD',NULL,NULL,NULL),(576,'BJ BOUJDOUR',NULL,NULL,'MA','2022-10-17 18:18:07','2022-10-17 18:18:08',NULL,NULL,NULL,NULL,NULL,56,'MAD',NULL,NULL,NULL),(577,'BD BOUJDOUR',NULL,NULL,'MA','2022-10-17 18:18:08','2022-10-17 18:18:08',NULL,NULL,NULL,NULL,NULL,56,'MAD',NULL,NULL,NULL),(578,'BT BOUJDOUR',NULL,NULL,'MA','2022-10-17 18:18:08','2022-10-17 18:18:08',NULL,NULL,NULL,NULL,NULL,56,'MAD',NULL,NULL,NULL),(579,'BT SIDI EL GHAZI',NULL,NULL,'MA','2022-10-17 18:18:08','2022-10-17 18:18:08',NULL,NULL,NULL,NULL,NULL,56,'MAD',NULL,NULL,NULL),(580,'BT OUED KRAA',NULL,NULL,'MA','2022-10-17 18:18:08','2022-10-17 18:18:08',NULL,NULL,NULL,NULL,NULL,56,'MAD',NULL,NULL,NULL),(581,'PM TARFAYA',NULL,NULL,'MA','2022-10-17 18:18:08','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(582,'BJ TARAFAYA',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(583,'BD TARFAYA',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(584,'BT TARFAYA',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(585,'BT DAWRA',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(586,'BT AKHFENIR',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(587,'PSP TARFAYA',NULL,NULL,'MA','2022-10-17 18:18:09','2022-10-17 18:18:09',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(588,'PSP AMEGRIOU',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,57,'MAD',NULL,NULL,NULL),(589,'PM MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(590,'PMA LOUDAYA',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(591,'BJ MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(592,'BD MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(593,'BT MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:10',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(594,'BT KETTARA',NULL,NULL,'MA','2022-10-17 18:18:10','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(595,'BT SIDI ZOUINE',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(596,'BT LOUDAYA',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(597,'BT OULED HASSOUNE',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(598,'BT AGAFAY',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(599,'BT SAADA',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(600,'BT TAMNSOURTE',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:11',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(601,'BT OUAHAT SIDI BRAHIM',NULL,NULL,'MA','2022-10-17 18:18:11','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(602,'BT TASSOULTANTE',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,58,'MAD',NULL,NULL,NULL),(603,'PM TAHANNAOUT',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(604,'BJ TAHANNAOUT',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(605,'BD TAHANNAOUT',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(606,'BT TAHANNAOUT',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:12',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(607,'BT AIT OURIR',NULL,NULL,'MA','2022-10-17 18:18:12','2022-10-17 18:18:13',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(608,'BT ASNI',NULL,NULL,'MA','2022-10-17 18:18:13','2022-10-17 18:18:13',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(609,'BT AMEZMIZ',NULL,NULL,'MA','2022-10-17 18:18:13','2022-10-17 18:18:13',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(610,'BT OURIKA',NULL,NULL,'MA','2022-10-17 18:18:13','2022-10-17 18:18:14',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(611,'BT TOUAMA',NULL,NULL,'MA','2022-10-17 18:18:14','2022-10-17 18:18:14',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(612,'BT SIDI ABDELLAH GHIAT',NULL,NULL,'MA','2022-10-17 18:18:14','2022-10-17 18:18:14',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(613,'BT TAMESLOHT',NULL,NULL,'MA','2022-10-17 18:18:14','2022-10-17 18:18:15',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(614,'BT CHOUITER',NULL,NULL,'MA','2022-10-17 18:18:15','2022-10-17 18:18:15',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(615,'PSP IMLIL',NULL,NULL,'MA','2022-10-17 18:18:15','2022-10-17 18:18:15',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(616,'PSP SITI FADMA',NULL,NULL,'MA','2022-10-17 18:18:15','2022-10-17 18:18:15',NULL,NULL,NULL,NULL,NULL,59,'MAD',NULL,NULL,NULL),(617,'PM CHICHAOUA',NULL,NULL,'MA','2022-10-17 18:18:15','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(618,'PMA CHICHAOUA',NULL,NULL,'MA','2022-10-17 18:18:16','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(619,'PMA IMINTANOUT',NULL,NULL,'MA','2022-10-17 18:18:16','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(620,'BJ CHICHAOUA',NULL,NULL,'MA','2022-10-17 18:18:16','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(621,'BD CHICHAOUA',NULL,NULL,'MA','2022-10-17 18:18:16','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(622,'BT CHICHAOUA',NULL,NULL,'MA','2022-10-17 18:18:16','2022-10-17 18:18:16',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(623,'BT IMINTANOUT',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(624,'BT HAD MEJJAT',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(625,'BT SIDI MOUKHTAR',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(626,'BT TIMEZGUIDIOUINE',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(627,'BT TAOULOUKOULT',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,60,'MAD',NULL,NULL,NULL),(628,'PM EL KALAA DES SRAGHNA',NULL,NULL,'MA','2022-10-17 18:18:17','2022-10-17 18:18:17',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(629,'BJ EL KALAA DES SRAGHNA',NULL,NULL,'MA','2022-10-17 18:18:18','2022-10-17 18:18:18',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(630,'BD EL KALAA DES SRAGHNA',NULL,NULL,'MA','2022-10-17 18:18:18','2022-10-17 18:18:18',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(631,'BT EL KALAA DES SRAGHNA',NULL,NULL,'MA','2022-10-17 18:18:18','2022-10-17 18:18:18',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(632,'BT TAMELALT',NULL,NULL,'MA','2022-10-17 18:18:18','2022-10-17 18:18:19',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(633,'BT AATTAOUIA',NULL,NULL,'MA','2022-10-17 18:18:19','2022-10-17 18:18:19',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(634,'BT SAHRIJ SIDI DRISS',NULL,NULL,'MA','2022-10-17 18:18:19','2022-10-17 18:18:19',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(635,'BT ARBAA GAZET',NULL,NULL,'MA','2022-10-17 18:18:19','2022-10-17 18:18:19',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(636,'BT SIDI RAHAL',NULL,NULL,'MA','2022-10-17 18:18:19','2022-10-17 18:18:20',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(637,'BT LAARARCHA',NULL,NULL,'MA','2022-10-17 18:18:20','2022-10-17 18:18:20',NULL,NULL,NULL,NULL,NULL,61,'MAD',NULL,NULL,NULL),(638,'PM BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:20','2022-10-17 18:18:20',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(639,'PMA SIDI BOU OTHMANE',NULL,NULL,'MA','2022-10-17 18:18:20','2022-10-17 18:18:20',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(640,'PMA BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:21','2022-10-17 18:18:21',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(641,'PMA SKHOUR DES RHAMNA',NULL,NULL,'MA','2022-10-17 18:18:21','2022-10-17 18:18:21',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(642,'BJ BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:21','2022-10-17 18:18:21',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(643,'BD BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:21','2022-10-17 18:18:21',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(644,'BT BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:22','2022-10-17 18:18:22',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(645,'BT SKHOUR DES RHAMNA',NULL,NULL,'MA','2022-10-17 18:18:22','2022-10-17 18:18:22',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(646,'BT SIDI BOU OTMANE',NULL,NULL,'MA','2022-10-17 18:18:22','2022-10-17 18:18:22',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(647,'BT TNINE BOUCHENE',NULL,NULL,'MA','2022-10-17 18:18:22','2022-10-17 18:18:22',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(648,'BT HAD RAS EL AIN',NULL,NULL,'MA','2022-10-17 18:18:22','2022-10-17 18:18:22',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(649,'BT N\'ZALAT LAADEM',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,62,'MAD',NULL,NULL,NULL),(650,'BA MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,63,'MAD',NULL,NULL,NULL),(651,'BGTA MARRAKECH',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,63,'MAD',NULL,NULL,NULL),(652,'PM BASE MILITAIRE BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,64,'MAD',NULL,NULL,NULL),(653,'BJ BASE MILITAIRE BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,64,'MAD',NULL,NULL,NULL),(654,'BT BASE MILITAIRE BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:23',NULL,NULL,NULL,NULL,NULL,64,'MAD',NULL,NULL,NULL),(655,'BMun BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:23','2022-10-17 18:18:24',NULL,NULL,NULL,NULL,NULL,64,'MAD',NULL,NULL,NULL),(656,'BA BASE MILITAIRE BENGUERIR',NULL,NULL,'MA','2022-10-17 18:18:24','2022-10-17 18:18:24',NULL,NULL,NULL,NULL,NULL,64,'MAD',NULL,NULL,NULL),(657,'PM MEKNES',NULL,NULL,'MA','2022-10-17 18:18:24','2022-10-17 18:18:24',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(658,'PMA MEJJAT',NULL,NULL,'MA','2022-10-17 18:18:24','2022-10-17 18:18:24',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(659,'PMA AIT OUALLAL',NULL,NULL,'MA','2022-10-17 18:18:24','2022-10-17 18:18:24',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(660,'BJ MEKNES',NULL,NULL,'MA','2022-10-17 18:18:24','2022-10-17 18:18:25',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(661,'BD MEKNES',NULL,NULL,'MA','2022-10-17 18:18:25','2022-10-17 18:18:25',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(662,'BT MEKNES',NULL,NULL,'MA','2022-10-17 18:18:25','2022-10-17 18:18:25',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(663,'BT AIN JEMAA',NULL,NULL,'MA','2022-10-17 18:18:25','2022-10-17 18:18:26',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(664,'BT AIN EL ORMA',NULL,NULL,'MA','2022-10-17 18:18:26','2022-10-17 18:18:26',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(665,'BT MOULAY DRISS ZERHOUN',NULL,NULL,'MA','2022-10-17 18:18:26','2022-10-17 18:18:26',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(666,'BT BOUFEKRANE',NULL,NULL,'MA','2022-10-17 18:18:26','2022-10-17 18:18:26',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(667,'BT OUISLANE',NULL,NULL,'MA','2022-10-17 18:18:27','2022-10-17 18:18:27',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(668,'BT N\'ZALAT BNI AMAR',NULL,NULL,'MA','2022-10-17 18:18:27','2022-10-17 18:18:27',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(669,'BT M\'HAYA',NULL,NULL,'MA','2022-10-17 18:18:27','2022-10-17 18:18:27',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(670,'BT MRHASSIYINE',NULL,NULL,'MA','2022-10-17 18:18:27','2022-10-17 18:18:28',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(671,'BMun MEKNES',NULL,NULL,'MA','2022-10-17 18:18:28','2022-10-17 18:18:28',NULL,NULL,NULL,NULL,NULL,65,'MAD',NULL,NULL,NULL),(672,'BJ EL HAJEB',NULL,NULL,'MA','2022-10-17 18:18:28','2022-10-17 18:18:28',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(673,'PM EL HAJEB',NULL,NULL,'MA','2022-10-17 18:18:28','2022-10-17 18:18:28',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(674,'BD EL HAJEB',NULL,NULL,'MA','2022-10-17 18:18:28','2022-10-17 18:18:29',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(675,'BT EL HAJEB',NULL,NULL,'MA','2022-10-17 18:18:29','2022-10-17 18:18:30',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(676,'BT AIT YAZEM',NULL,NULL,'MA','2022-10-17 18:18:30','2022-10-17 18:18:30',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(677,'BT AIN TAOUJTATE',NULL,NULL,'MA','2022-10-17 18:18:30','2022-10-17 18:18:30',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(678,'BT AGOURAY',NULL,NULL,'MA','2022-10-17 18:18:30','2022-10-17 18:18:30',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(679,'BT SEBAA AIOUN',NULL,NULL,'MA','2022-10-17 18:18:30','2022-10-17 18:18:31',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(680,'BT BOUDERBALA',NULL,NULL,'MA','2022-10-17 18:18:31','2022-10-17 18:18:31',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(681,'BT SEBT JAHJOUH',NULL,NULL,'MA','2022-10-17 18:18:31','2022-10-17 18:18:31',NULL,NULL,NULL,NULL,NULL,66,'MAD',NULL,NULL,NULL),(682,'BJ AZROU',NULL,NULL,'MA','2022-10-17 18:18:31','2022-10-17 18:18:31',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(683,'PM AZROU',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(684,'BD AZROU',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(685,'BT AZROU',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(686,'BT AIN LEUH',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(687,'BT HAD OUED IFRANE',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,67,'MAD',NULL,NULL,NULL),(688,'PM IFRANE',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:32',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(689,'BJ IFRANE',NULL,NULL,'MA','2022-10-17 18:18:32','2022-10-17 18:18:33',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(690,'BD IFRANE',NULL,NULL,'MA','2022-10-17 18:18:33','2022-10-17 18:18:33',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(691,'BT IFRANE',NULL,NULL,'MA','2022-10-17 18:18:33','2022-10-17 18:18:33',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(692,'BT TIMAHDITE',NULL,NULL,'MA','2022-10-17 18:18:33','2022-10-17 18:18:33',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(693,'BT DAYET AOUA',NULL,NULL,'MA','2022-10-17 18:18:33','2022-10-17 18:18:34',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(694,'Bde Mont IFRANE',NULL,NULL,'MA','2022-10-17 18:18:34','2022-10-17 18:18:34',NULL,NULL,NULL,NULL,NULL,68,'MAD',NULL,NULL,NULL),(695,'PM NADOR',NULL,NULL,'MA','2022-10-17 18:18:34','2022-10-17 18:18:34',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(696,'BM NADOR',NULL,NULL,'MA','2022-10-17 18:18:35','2022-10-17 18:18:35',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(697,'BJ NADOR',NULL,NULL,'MA','2022-10-17 18:18:35','2022-10-17 18:18:35',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(698,'BD NADOR',NULL,NULL,'MA','2022-10-17 18:18:35','2022-10-17 18:18:35',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(699,'BT NADOR',NULL,NULL,'MA','2022-10-17 18:18:36','2022-10-17 18:18:36',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(700,'BT IKSANE',NULL,NULL,'MA','2022-10-17 18:18:36','2022-10-17 18:18:36',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(701,'BT SELOUANE',NULL,NULL,'MA','2022-10-17 18:18:36','2022-10-17 18:18:37',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(702,'BT ZEGHANGHANE',NULL,NULL,'MA','2022-10-17 18:18:37','2022-10-17 18:18:37',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(703,'BT BENI CHIKER',NULL,NULL,'MA','2022-10-17 18:18:37','2022-10-17 18:18:37',NULL,NULL,NULL,NULL,NULL,69,'MAD',NULL,NULL,NULL),(704,'PM ZAIOU',NULL,NULL,'MA','2022-10-17 18:18:37','2022-10-17 18:18:37',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(705,'BJ ZAIOU',NULL,NULL,'MA','2022-10-17 18:18:38','2022-10-17 18:18:38',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(706,'BD ZAIOU',NULL,NULL,'MA','2022-10-17 18:18:38','2022-10-17 18:18:38',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(707,'BT ZAIOU',NULL,NULL,'MA','2022-10-17 18:18:38','2022-10-17 18:18:38',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(708,'BT AL AAROUI',NULL,NULL,'MA','2022-10-17 18:18:38','2022-10-17 18:18:38',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(709,'BT RAS KEBDANA',NULL,NULL,'MA','2022-10-17 18:18:39','2022-10-17 18:18:39',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(710,'BT KABDANA',NULL,NULL,'MA','2022-10-17 18:18:39','2022-10-17 18:18:39',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(711,'BT TIZTOUTINE',NULL,NULL,'MA','2022-10-17 18:18:39','2022-10-17 18:18:40',NULL,NULL,NULL,NULL,NULL,70,'MAD',NULL,NULL,NULL),(712,'PM AZIB MIDAR',NULL,NULL,'MA','2022-10-17 18:18:40','2022-10-17 18:18:40',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(713,'BJ AZIB MIDAR',NULL,NULL,'MA','2022-10-17 18:18:40','2022-10-17 18:18:40',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(714,'BD AZIB MIDAR',NULL,NULL,'MA','2022-10-17 18:18:41','2022-10-17 18:18:41',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(715,'BT AZIB MIDAR',NULL,NULL,'MA','2022-10-17 18:18:41','2022-10-17 18:18:41',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(716,'BT DRIOUCH',NULL,NULL,'MA','2022-10-17 18:18:41','2022-10-17 18:18:42',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(717,'BT BOUDINAR',NULL,NULL,'MA','2022-10-17 18:18:42','2022-10-17 18:18:42',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(718,'BT TSAFT',NULL,NULL,'MA','2022-10-17 18:18:42','2022-10-17 18:18:42',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(719,'BT BENI SAID',NULL,NULL,'MA','2022-10-17 18:18:42','2022-10-17 18:18:42',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(720,'BT AIN ZOHRA',NULL,NULL,'MA','2022-10-17 18:18:42','2022-10-17 18:18:42',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(721,'BT BNI OULICHEK',NULL,NULL,'MA','2022-10-17 18:18:42','2022-10-17 18:18:43',NULL,NULL,NULL,NULL,NULL,71,'MAD',NULL,NULL,NULL),(722,'BGTA AL AAROUI',NULL,NULL,'MA','2022-10-17 18:18:43','2022-10-17 18:56:31',NULL,NULL,NULL,NULL,NULL,1041,'MAD',NULL,NULL,NULL),(723,'PM OUARZAZATE',NULL,NULL,'MA','2022-10-17 18:18:43','2022-10-17 18:18:43',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(724,'BJ OUARZAZATE',NULL,NULL,'MA','2022-10-17 18:18:44','2022-10-17 18:18:44',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(725,'BD OUARZAZATE',NULL,NULL,'MA','2022-10-17 18:18:44','2022-10-17 18:18:44',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(726,'BT OUARZAZATE',NULL,NULL,'MA','2022-10-17 18:18:44','2022-10-17 18:18:44',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(727,'BT TAZNAKTE',NULL,NULL,'MA','2022-10-17 18:18:44','2022-10-17 18:18:45',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(728,'BT IGHREM NOUGDAL',NULL,NULL,'MA','2022-10-17 18:18:45','2022-10-17 18:18:45',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(729,'BT SKOURA',NULL,NULL,'MA','2022-10-17 18:18:45','2022-10-17 18:18:45',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(730,'BT TELOUET',NULL,NULL,'MA','2022-10-17 18:18:46','2022-10-17 18:18:46',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(731,'BT AMERZGANE',NULL,NULL,'MA','2022-10-17 18:18:46','2022-10-17 18:18:46',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(732,'BT MOGHRANE',NULL,NULL,'MA','2022-10-17 18:18:46','2022-10-17 18:18:46',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(733,'BSur Centrale Solaire NOOR',NULL,NULL,'MA','2022-10-17 18:18:47','2022-10-17 18:18:47',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(734,'BGTA OUARZAZATE',NULL,NULL,'MA','2022-10-17 18:18:47','2022-10-17 18:18:47',NULL,NULL,NULL,NULL,NULL,73,'MAD',NULL,NULL,NULL),(735,'PM TINGHIR',NULL,NULL,'MA','2022-10-17 18:18:47','2022-10-17 18:18:47',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(736,'BJ TINGHIR',NULL,NULL,'MA','2022-10-17 18:18:47','2022-10-17 18:18:47',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(737,'BD TINGHIR',NULL,NULL,'MA','2022-10-17 18:18:48','2022-10-17 18:18:48',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(738,'BT TINGHIR',NULL,NULL,'MA','2022-10-17 18:18:48','2022-10-17 18:18:49',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(739,'BT BOUMALNE DADES',NULL,NULL,'MA','2022-10-17 18:18:49','2022-10-17 18:18:49',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(740,'BT M\'SEMRIR',NULL,NULL,'MA','2022-10-17 18:18:49','2022-10-17 18:18:49',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(741,'BT KELAA M\'GOUNA',NULL,NULL,'MA','2022-10-17 18:18:49','2022-10-17 18:18:49',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(742,'BT ALNIF',NULL,NULL,'MA','2022-10-17 18:18:49','2022-10-17 18:18:49',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(743,'BT IMIDER',NULL,NULL,'MA','2022-10-17 18:18:49','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(744,'BT TAGHZOUTE',NULL,NULL,'MA','2022-10-17 18:18:50','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(745,'BT ASSOUL',NULL,NULL,'MA','2022-10-17 18:18:50','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,74,'MAD',NULL,NULL,NULL),(746,'BJ ZAGORA',NULL,NULL,'MA','2022-10-17 18:18:50','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(747,'BD ZAGORA',NULL,NULL,'MA','2022-10-17 18:18:50','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(748,'BGTA ZAGORA',NULL,NULL,'MA','2022-10-17 18:18:50','2022-10-17 18:18:50',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(749,'BT ZAGORA',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:51',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(750,'BT AGDEZ',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:51',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(751,'BT TAGOUNITE',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:51',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(752,'BT MHAMID EL GHOUZLANE',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:51',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(753,'BT TAZARINE',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:51',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(754,'BT NKOB',NULL,NULL,'MA','2022-10-17 18:18:51','2022-10-17 18:18:52',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(755,'BT TAMEGROUT',NULL,NULL,'MA','2022-10-17 18:18:52','2022-10-17 18:18:52',NULL,NULL,NULL,NULL,NULL,75,'MAD',NULL,NULL,NULL),(756,'PM OUJDA',NULL,NULL,'MA','2022-10-17 18:18:52','2022-10-17 18:18:52',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(757,'PMA OUJDA',NULL,NULL,'MA','2022-10-17 18:18:52','2022-10-17 18:18:52',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(758,'BJ OUJDA',NULL,NULL,'MA','2022-10-17 18:18:52','2022-10-17 18:18:53',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(759,'BD OUJDA',NULL,NULL,'MA','2022-10-17 18:18:53','2022-10-17 18:18:53',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(760,'BT OUJDA',NULL,NULL,'MA','2022-10-17 18:18:53','2022-10-17 18:18:53',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(761,'BT BENI DRAR',NULL,NULL,'MA','2022-10-17 18:18:53','2022-10-17 18:18:53',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(762,'BT NAIMA',NULL,NULL,'MA','2022-10-17 18:18:53','2022-10-17 18:18:53',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(763,'BT AIN SFA',NULL,NULL,'MA','2022-10-17 18:18:53','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(764,'BT AHL ANGAD',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(765,'Bde Sur DOUGHMANIA',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,76,'MAD',NULL,NULL,NULL),(766,'PM TAOURIRT',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(767,'PMA TAOURIRT',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(768,'BJ TAOURIRT',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:54',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(769,'BD TAOURIRT',NULL,NULL,'MA','2022-10-17 18:18:54','2022-10-17 18:18:55',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(770,'BT TAOURIRT',NULL,NULL,'MA','2022-10-17 18:18:55','2022-10-17 18:18:55',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(771,'BT EL AIOUN',NULL,NULL,'MA','2022-10-17 18:18:55','2022-10-17 18:18:55',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(772,'BT DEBDOU',NULL,NULL,'MA','2022-10-17 18:18:55','2022-10-17 18:18:55',NULL,NULL,NULL,NULL,NULL,77,'MAD',NULL,NULL,NULL),(773,'BGTA OUJDA ANGAD',NULL,NULL,'MA','2022-10-17 18:18:55','2022-10-17 18:18:55',NULL,NULL,NULL,NULL,NULL,78,'MAD',NULL,NULL,NULL),(774,'PM BERKANE',NULL,NULL,'MA','2022-10-17 18:18:55','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(775,'BJ BERKANE',NULL,NULL,'MA','2022-10-17 18:18:56','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(776,'BD BERKANE',NULL,NULL,'MA','2022-10-17 18:18:56','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(777,'BT BERKANE',NULL,NULL,'MA','2022-10-17 18:18:56','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(778,'BT SAAIDIA',NULL,NULL,'MA','2022-10-17 18:18:56','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(779,'BT TAFOUGHALT',NULL,NULL,'MA','2022-10-17 18:18:56','2022-10-17 18:18:56',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(780,'BT AHFIR',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:57',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(781,'BT AKLIM',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:57',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(782,'BM MARINA FADESA SAADIA',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:57',NULL,NULL,NULL,NULL,NULL,79,'MAD',NULL,NULL,NULL),(783,'BJ JERADA',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:57',NULL,NULL,NULL,NULL,NULL,80,'MAD',NULL,NULL,NULL),(784,'BD JERADA',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:57',NULL,NULL,NULL,NULL,NULL,80,'MAD',NULL,NULL,NULL),(785,'BT JERADA',NULL,NULL,'MA','2022-10-17 18:18:57','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,80,'MAD',NULL,NULL,NULL),(786,'BT TOUISSIT BOUBKER',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,80,'MAD',NULL,NULL,NULL),(787,'BT AIN BNI MATHAR',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,80,'MAD',NULL,NULL,NULL),(788,'PMA GUERCIF',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(789,'PM GUERCIF',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(790,'BJ GUERCIF',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:58',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(791,'BD GUERCIF',NULL,NULL,'MA','2022-10-17 18:18:58','2022-10-17 18:18:59',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(792,'BT GUERCIF',NULL,NULL,'MA','2022-10-17 18:18:59','2022-10-17 18:18:59',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(793,'BT SAKA',NULL,NULL,'MA','2022-10-17 18:18:59','2022-10-17 18:18:59',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(794,'BT BERKINE',NULL,NULL,'MA','2022-10-17 18:18:59','2022-10-17 18:18:59',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(795,'BT MAZGUITAM',NULL,NULL,'MA','2022-10-17 18:18:59','2022-10-17 18:18:59',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(796,'BT TADDART',NULL,NULL,'MA','2022-10-17 18:18:59','2022-10-17 18:19:00',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(797,'BT LAMRIJA',NULL,NULL,'MA','2022-10-17 18:19:00','2022-10-17 18:19:00',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(798,'BMun M\'SOUN',NULL,NULL,'MA','2022-10-17 18:19:00','2022-10-17 18:19:00',NULL,NULL,NULL,NULL,NULL,81,'MAD',NULL,NULL,NULL),(799,'PM RABAT',NULL,NULL,'MA','2022-10-17 18:19:00','2022-10-17 18:19:00',NULL,NULL,NULL,NULL,NULL,82,'MAD',NULL,NULL,NULL),(800,'BM RABAT',NULL,NULL,'MA','2022-10-17 18:19:00','2022-10-17 18:19:01',NULL,NULL,NULL,NULL,NULL,82,'MAD',NULL,NULL,NULL),(801,'BJ RABAT',NULL,NULL,'MA','2022-10-17 18:19:01','2022-10-17 18:19:01',NULL,NULL,NULL,NULL,NULL,82,'MAD',NULL,NULL,NULL),(802,'BD RABAT',NULL,NULL,'MA','2022-10-17 18:19:01','2022-10-17 18:19:01',NULL,NULL,NULL,NULL,NULL,82,'MAD',NULL,NULL,NULL),(803,'BT RABAT',NULL,NULL,'MA','2022-10-17 18:19:01','2022-10-17 18:19:01',NULL,NULL,NULL,NULL,NULL,82,'MAD',NULL,NULL,NULL),(804,'BM MARINA BOUREGREG',NULL,NULL,'MA','2022-10-17 18:19:02','2022-10-17 18:19:02',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(805,'PM SALE',NULL,NULL,'MA','2022-10-17 18:19:02','2022-10-17 18:19:02',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(806,'PMA SALA AL JADIDA',NULL,NULL,'MA','2022-10-17 18:19:02','2022-10-17 18:19:02',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(807,'BJ SALE',NULL,NULL,'MA','2022-10-17 18:19:02','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(808,'BD SALE',NULL,NULL,'MA','2022-10-17 18:19:03','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(809,'BT SALE',NULL,NULL,'MA','2022-10-17 18:19:03','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(810,'BT BOUKNADEL',NULL,NULL,'MA','2022-10-17 18:19:03','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(811,'BT LAAYAYDA',NULL,NULL,'MA','2022-10-17 18:19:03','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(812,'BT SHOUL',NULL,NULL,'MA','2022-10-17 18:19:03','2022-10-17 18:19:03',NULL,NULL,NULL,NULL,NULL,83,'MAD',NULL,NULL,NULL),(813,'PM AIN EL AOUDA',NULL,NULL,'MA','2022-10-17 18:19:04','2022-10-17 18:19:04',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(814,'PMA EL MENZEH',NULL,NULL,'MA','2022-10-17 18:19:04','2022-10-17 18:19:04',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(815,'BJ AIN EL AOUDA',NULL,NULL,'MA','2022-10-17 18:19:04','2022-10-17 18:19:04',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(816,'BD AIN EL AOUDA',NULL,NULL,'MA','2022-10-17 18:19:04','2022-10-17 18:19:04',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(817,'BT SIDI YAHYA DES ZAERS',NULL,NULL,'MA','2022-10-17 18:19:04','2022-10-17 18:19:05',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(818,'BT TAMESNA',NULL,NULL,'MA','2022-10-17 18:19:05','2022-10-17 18:19:05',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(819,'BT EL MANZEH',NULL,NULL,'MA','2022-10-17 18:19:05','2022-10-17 18:19:05',NULL,NULL,NULL,NULL,NULL,84,'MAD',NULL,NULL,NULL),(820,'PM TEMARA',NULL,NULL,'MA','2022-10-17 18:19:05','2022-10-17 18:19:05',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(821,'PMA TEMARA',NULL,NULL,'MA','2022-10-17 18:19:05','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(822,'BJ TEMARA',NULL,NULL,'MA','2022-10-17 18:19:06','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(823,'BD TEMARA',NULL,NULL,'MA','2022-10-17 18:19:06','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(824,'BT TEMARA',NULL,NULL,'MA','2022-10-17 18:19:06','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(825,'BT TEMARA-Plage',NULL,NULL,'MA','2022-10-17 18:19:06','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(826,'BT HARHOURA',NULL,NULL,'MA','2022-10-17 18:19:06','2022-10-17 18:19:06',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(827,'BT MERS AL KHEIR',NULL,NULL,'MA','2022-10-17 18:19:07','2022-10-17 18:19:07',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(828,'PSP SABLES D\'OR',NULL,NULL,'MA','2022-10-17 18:19:07','2022-10-17 18:19:07',NULL,NULL,NULL,NULL,NULL,85,'MAD',NULL,NULL,NULL),(829,'PM SKHIRATE',NULL,NULL,'MA','2022-10-17 18:19:07','2022-10-17 18:19:07',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(830,'BJ SKHIRATE',NULL,NULL,'MA','2022-10-17 18:19:07','2022-10-17 18:19:07',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(831,'BD SKHIRATE',NULL,NULL,'MA','2022-10-17 18:19:07','2022-10-17 18:19:07',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(832,'BT SKHIRATE Centre',NULL,NULL,'MA','2022-10-17 18:19:08','2022-10-17 18:19:08',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(833,'BT SKHIRATE Plage',NULL,NULL,'MA','2022-10-17 18:19:08','2022-10-17 18:19:08',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(834,'BT LAGHOUAZI',NULL,NULL,'MA','2022-10-17 18:19:08','2022-10-17 18:19:08',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(835,'BT AIN AL HAYATE',NULL,NULL,'MA','2022-10-17 18:19:08','2022-10-17 18:19:09',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(836,'BT SEBBAH',NULL,NULL,'MA','2022-10-17 18:19:09','2022-10-17 18:19:09',NULL,NULL,NULL,NULL,NULL,86,'MAD',NULL,NULL,NULL),(837,'BA SALE',NULL,NULL,'MA','2022-10-17 18:19:09','2022-10-17 18:19:09',NULL,NULL,NULL,NULL,NULL,87,'MAD',NULL,NULL,NULL),(838,'BGTA SALE',NULL,NULL,'MA','2022-10-17 18:19:09','2022-10-17 18:19:09',NULL,NULL,NULL,NULL,NULL,88,'MAD',NULL,NULL,NULL),(839,'PM SAFI',NULL,NULL,'MA','2022-10-17 18:19:09','2022-10-17 18:19:10',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(840,'PMA SAFI',NULL,NULL,'MA','2022-10-17 18:19:10','2022-10-17 18:19:10',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(841,'BM SAFI',NULL,NULL,'MA','2022-10-17 18:19:10','2022-10-17 18:19:10',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(842,'BJ SAFI',NULL,NULL,'MA','2022-10-17 18:19:10','2022-10-17 18:19:11',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(843,'BD SAFI',NULL,NULL,'MA','2022-10-17 18:19:11','2022-10-17 18:19:11',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(844,'BT SAFI',NULL,NULL,'MA','2022-10-17 18:19:11','2022-10-17 18:19:11',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(845,'BT SEBT GZOULA',NULL,NULL,'MA','2022-10-17 18:19:11','2022-10-17 18:19:11',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(846,'BT JEMAAT SHAIM',NULL,NULL,'MA','2022-10-17 18:19:12','2022-10-17 18:19:12',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(847,'BT TLET BOUGUEDRA',NULL,NULL,'MA','2022-10-17 18:19:12','2022-10-17 18:19:12',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(848,'BT EL BEDDOUZA',NULL,NULL,'MA','2022-10-17 18:19:12','2022-10-17 18:19:12',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(849,'BT SOUIRIA LAQDIMA',NULL,NULL,'MA','2022-10-17 18:19:12','2022-10-17 18:19:12',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(850,'BT MOUL EL BERGUI',NULL,NULL,'MA','2022-10-17 18:19:12','2022-10-17 18:19:12',NULL,NULL,NULL,NULL,NULL,89,'MAD',NULL,NULL,NULL),(851,'PM YOUSSOUFIA',NULL,NULL,'MA','2022-10-17 18:19:13','2022-10-17 18:19:13',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(852,'BJ YOUSSOUFIA',NULL,NULL,'MA','2022-10-17 18:19:13','2022-10-17 18:19:13',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(853,'BD YOUSSOUFIA',NULL,NULL,'MA','2022-10-17 18:19:13','2022-10-17 18:19:14',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(854,'BT YOUSSOUFIA',NULL,NULL,'MA','2022-10-17 18:19:14','2022-10-17 18:19:14',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(855,'BT CHEMAIA',NULL,NULL,'MA','2022-10-17 18:19:14','2022-10-17 18:19:15',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(856,'BT RAS EL AIN',NULL,NULL,'MA','2022-10-17 18:19:15','2022-10-17 18:19:15',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(857,'BT SIDI CHIKER',NULL,NULL,'MA','2022-10-17 18:19:15','2022-10-17 18:19:15',NULL,NULL,NULL,NULL,NULL,90,'MAD',NULL,NULL,NULL),(858,'PM SETTAT',NULL,NULL,'MA','2022-10-17 18:19:15','2022-10-17 18:19:16',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(859,'PMA SETTAT',NULL,NULL,'MA','2022-10-17 18:19:16','2022-10-17 18:19:16',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(860,'PMA BEN AHMED',NULL,NULL,'MA','2022-10-17 18:19:16','2022-10-17 18:19:16',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(861,'BJ SETTAT',NULL,NULL,'MA','2022-10-17 18:19:16','2022-10-17 18:19:16',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(862,'BD SETTAT',NULL,NULL,'MA','2022-10-17 18:19:16','2022-10-17 18:19:17',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(863,'BT SETTAT',NULL,NULL,'MA','2022-10-17 18:19:17','2022-10-17 18:19:17',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(864,'BT BEN AHMED',NULL,NULL,'MA','2022-10-17 18:19:17','2022-10-17 18:19:17',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(865,'BT EL BROUJ',NULL,NULL,'MA','2022-10-17 18:19:17','2022-10-17 18:19:17',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(866,'BT MECHRAA BEN ABOU',NULL,NULL,'MA','2022-10-17 18:19:17','2022-10-17 18:19:17',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(867,'BT OULED SAID',NULL,NULL,'MA','2022-10-17 18:19:17','2022-10-17 18:19:18',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(868,'BT SIDI HAJJAJ',NULL,NULL,'MA','2022-10-17 18:19:18','2022-10-17 18:19:18',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(869,'BT SEBT O.FRIHA',NULL,NULL,'MA','2022-10-17 18:19:18','2022-10-17 18:19:18',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(870,'BT TLET LOULED',NULL,NULL,'MA','2022-10-17 18:19:18','2022-10-17 18:19:18',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(871,'BT RAS EL AIN CHAOUIA',NULL,NULL,'MA','2022-10-17 18:19:18','2022-10-17 18:19:19',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(872,'BT GUISSER',NULL,NULL,'MA','2022-10-17 18:19:19','2022-10-17 18:19:27',NULL,NULL,NULL,NULL,NULL,91,'MAD',NULL,NULL,NULL),(873,'PM BERRECHID',NULL,NULL,'MA','2022-10-17 18:19:35','2022-10-17 18:19:35',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(874,'PMA BERRECHID',NULL,NULL,'MA','2022-10-17 18:19:35','2022-10-17 18:19:35',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(875,'PMA BERRECHID EST',NULL,NULL,'MA','2022-10-17 18:19:35','2022-10-17 18:19:36',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(876,'PMA HAD SOUALEM',NULL,NULL,'MA','2022-10-17 18:19:36','2022-10-17 18:19:36',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(877,'BJ BERRECHID',NULL,NULL,'MA','2022-10-17 18:19:36','2022-10-17 18:19:36',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(878,'BD BERRECHID',NULL,NULL,'MA','2022-10-17 18:19:36','2022-10-17 18:19:36',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(879,'BT BERRECHID',NULL,NULL,'MA','2022-10-17 18:19:36','2022-10-17 18:19:36',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(880,'BT DEROUA',NULL,NULL,'MA','2022-10-17 18:19:36','2022-10-17 18:19:37',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(881,'BT EL GARA',NULL,NULL,'MA','2022-10-17 18:19:37','2022-10-17 18:19:37',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(882,'BT HAD SOUALEM',NULL,NULL,'MA','2022-10-17 18:19:37','2022-10-17 18:19:37',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(883,'BT SOUK JEMAA O. ABBOU',NULL,NULL,'MA','2022-10-17 18:19:37','2022-10-17 18:19:37',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(884,'BT SIDI RAHAL CHATAI',NULL,NULL,'MA','2022-10-17 18:19:37','2022-10-17 18:19:37',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(885,'PSP SOUALEM TRIFYA',NULL,NULL,'MA','2022-10-17 18:19:37','2022-10-17 18:19:38',NULL,NULL,NULL,NULL,NULL,92,'MAD',NULL,NULL,NULL),(886,'PM BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:38','2022-10-17 18:19:38',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(887,'BJ BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:38','2022-10-17 18:19:38',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(888,'BD BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:38','2022-10-17 18:19:38',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(889,'BT BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:38','2022-10-17 18:19:38',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(890,'BT MELLILA',NULL,NULL,'MA','2022-10-17 18:19:38','2022-10-17 18:19:39',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(891,'BT SIDI BETTACHE',NULL,NULL,'MA','2022-10-17 18:19:39','2022-10-17 18:19:39',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(892,'BT FDALATE',NULL,NULL,'MA','2022-10-17 18:19:39','2022-10-17 18:19:39',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(893,'BA BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:39','2022-10-17 18:19:39',NULL,NULL,NULL,NULL,NULL,93,'MAD',NULL,NULL,NULL),(894,'PM BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:40','2022-10-17 18:19:40',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(895,'PMA BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:40','2022-10-17 18:19:40',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(896,'BJ BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:40','2022-10-17 18:19:40',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(897,'BD BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:40','2022-10-17 18:19:41',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(898,'BT BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:41','2022-10-17 18:19:41',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(899,'BT EL MANSOURIA',NULL,NULL,'MA','2022-10-17 18:19:41','2022-10-17 18:19:41',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(900,'PSP BOUZNIKA',NULL,NULL,'MA','2022-10-17 18:19:41','2022-10-17 18:19:41',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(901,'PSP BOUZNIKA PLAGE',NULL,NULL,'MA','2022-10-17 18:19:41','2022-10-17 18:19:41',NULL,NULL,NULL,NULL,NULL,94,'MAD',NULL,NULL,NULL),(902,'BMun BENSLIMANE',NULL,NULL,'MA','2022-10-17 18:19:41','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,95,'MAD',NULL,NULL,NULL),(903,'PM SIDI KACEM',NULL,NULL,'MA','2022-10-17 18:19:42','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(904,'BJ SIDI KACEM',NULL,NULL,'MA','2022-10-17 18:19:42','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(905,'BD SIDI KACEM',NULL,NULL,'MA','2022-10-17 18:19:42','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(906,'BT SIDI KACEM',NULL,NULL,'MA','2022-10-17 18:19:42','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(907,'BT MECHRAA BEL KSIRI',NULL,NULL,'MA','2022-10-17 18:19:42','2022-10-17 18:19:42',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(908,'BT DAR EL GUEDDARI',NULL,NULL,'MA','2022-10-17 18:19:43','2022-10-17 18:19:43',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(909,'BT HOUAFATE',NULL,NULL,'MA','2022-10-17 18:19:43','2022-10-17 18:19:43',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(910,'BT ZAGGOTA',NULL,NULL,'MA','2022-10-17 18:19:43','2022-10-17 18:19:43',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(911,'BT KHENICHET',NULL,NULL,'MA','2022-10-17 18:19:43','2022-10-17 18:19:43',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(912,'BT HAD KOURT',NULL,NULL,'MA','2022-10-17 18:19:43','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(913,'BT JORF EL MELHA',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(914,'BT AIN DFALI',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(915,'BT SIDI AMEUR AL HADI',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(916,'BT AL MOUKHTAR',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,96,'MAD',NULL,NULL,NULL),(917,'BA SIDI SLIMANE',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,97,'MAD',NULL,NULL,NULL),(918,'PM SIDI SLIMANE',NULL,NULL,'MA','2022-10-17 18:19:44','2022-10-17 18:19:44',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(919,'BJ SIDI SLIMANE',NULL,NULL,'MA','2022-10-17 18:19:45','2022-10-17 18:19:45',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(920,'BD SIDI SLIMANE',NULL,NULL,'MA','2022-10-17 18:19:45','2022-10-17 18:19:45',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(921,'BT M\'SAADA',NULL,NULL,'MA','2022-10-17 18:19:45','2022-10-17 18:19:45',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(922,'BT SIDI SLIMANE',NULL,NULL,'MA','2022-10-17 18:19:45','2022-10-17 18:19:45',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(923,'BT DAR BELAMRI',NULL,NULL,'MA','2022-10-17 18:19:45','2022-10-17 18:19:45',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(924,'BT KCEIBIA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(925,'BT SIDI YAHYA DU GHARB',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,98,'MAD',NULL,NULL,NULL),(926,'PMA TAZA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(927,'PM TAZA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(928,'BJ TAZA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(929,'BD TAZA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:46',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(930,'BT TAZA',NULL,NULL,'MA','2022-10-17 18:19:46','2022-10-17 18:19:47',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(931,'BT AKNOUL',NULL,NULL,'MA','2022-10-17 18:19:47','2022-10-17 18:19:47',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(932,'BT TAINESTE',NULL,NULL,'MA','2022-10-17 18:19:47','2022-10-17 18:19:47',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(933,'BT AJDIR',NULL,NULL,'MA','2022-10-17 18:19:47','2022-10-17 18:19:47',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(934,'BT MAGHRAOUA',NULL,NULL,'MA','2022-10-17 18:19:47','2022-10-17 18:19:48',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(935,'BT HAD M\'SILA',NULL,NULL,'MA','2022-10-17 18:19:48','2022-10-17 18:19:48',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(936,'BT KAF EL GHAR',NULL,NULL,'MA','2022-10-17 18:19:48','2022-10-17 18:19:48',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(937,'BT TIZI OUSLI',NULL,NULL,'MA','2022-10-17 18:19:48','2022-10-17 18:19:48',NULL,NULL,NULL,NULL,NULL,99,'MAD',NULL,NULL,NULL),(938,'PM OUED AMLIL',NULL,NULL,'MA','2022-10-17 18:19:48','2022-10-17 18:19:49',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(939,'BJ OUED AMLIL',NULL,NULL,'MA','2022-10-17 18:19:49','2022-10-17 18:19:49',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(940,'BD OUED AMLIL',NULL,NULL,'MA','2022-10-17 18:19:49','2022-10-17 18:19:49',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(941,'BT OUED AMLIL',NULL,NULL,'MA','2022-10-17 18:19:49','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(942,'BT MATMATA',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(943,'BT TAHLA',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(944,'BT BNI FRASSEN',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,100,'MAD',NULL,NULL,NULL),(945,'BJ AKNOUL',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,101,'MAD',NULL,NULL,NULL),(946,'PM TETOUAN',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:50',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(947,'PMA SMIR',NULL,NULL,'MA','2022-10-17 18:19:50','2022-10-17 18:19:51',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(948,'BM M\'DIEK',NULL,NULL,'MA','2022-10-17 18:19:51','2022-10-17 18:19:51',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(949,'BJ TETOUAN',NULL,NULL,'MA','2022-10-17 18:19:51','2022-10-17 18:19:51',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(950,'BD TETOUAN',NULL,NULL,'MA','2022-10-17 18:19:51','2022-10-17 18:19:51',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(951,'BT TETOUAN',NULL,NULL,'MA','2022-10-17 18:19:51','2022-10-17 18:19:52',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(952,'BT FNIDEK',NULL,NULL,'MA','2022-10-17 18:19:52','2022-10-17 18:19:52',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(953,'BT OUED LAOU',NULL,NULL,'MA','2022-10-17 18:19:52','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(954,'BT BNI HASSANE',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(955,'BT JBEL LAHBIB',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(956,'BT AZLA-ZAITOUNE',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(957,'BT BNI KARRICH',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(958,'BGTA SANIAT RMEL',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,102,'MAD',NULL,NULL,NULL),(959,'PM OUAZZANE',NULL,NULL,'MA','2022-10-17 18:19:53','2022-10-17 18:19:53',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(960,'BJ OUAZZANE',NULL,NULL,'MA','2022-10-17 18:19:54','2022-10-17 18:19:54',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(961,'BD OUAZZANE',NULL,NULL,'MA','2022-10-17 18:19:54','2022-10-17 18:19:54',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(962,'BT OUAZZANE',NULL,NULL,'MA','2022-10-17 18:19:54','2022-10-17 18:19:54',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(963,'BT AIN DORRIJ',NULL,NULL,'MA','2022-10-17 18:19:55','2022-10-17 18:19:55',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(964,'BT MJAARA',NULL,NULL,'MA','2022-10-17 18:19:55','2022-10-17 18:19:55',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(965,'BT ZOUMI',NULL,NULL,'MA','2022-10-17 18:19:55','2022-10-17 18:19:55',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(966,'BT MOQRISSAT',NULL,NULL,'MA','2022-10-17 18:19:55','2022-10-17 18:19:55',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(967,'BT SIDI REDOUANE',NULL,NULL,'MA','2022-10-17 18:19:55','2022-10-17 18:19:55',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(968,'BT BRIKCHA',NULL,NULL,'MA','2022-10-17 18:19:56','2022-10-17 18:19:56',NULL,NULL,NULL,NULL,NULL,103,'MAD',NULL,NULL,NULL),(969,'PM CHAOUEN',NULL,NULL,'MA','2022-10-17 18:19:56','2022-10-17 18:19:56',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(970,'BJ CHAOUEN',NULL,NULL,'MA','2022-10-17 18:19:56','2022-10-17 18:19:56',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(971,'BD CHAOUEN',NULL,NULL,'MA','2022-10-17 18:19:56','2022-10-17 18:19:57',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(972,'BT CHAOUEN',NULL,NULL,'MA','2022-10-17 18:19:57','2022-10-17 18:19:57',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(973,'BT BENI AHMED',NULL,NULL,'MA','2022-10-17 18:19:57','2022-10-17 18:19:57',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(974,'BT JEBHA',NULL,NULL,'MA','2022-10-17 18:19:57','2022-10-17 18:19:57',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(975,'BT HAD GHDIR LAKROUCH',NULL,NULL,'MA','2022-10-17 18:19:57','2022-10-17 18:19:57',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(976,'BT STEHA',NULL,NULL,'MA','2022-10-17 18:19:58','2022-10-17 18:19:58',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(977,'BT BAB BERRED',NULL,NULL,'MA','2022-10-17 18:19:58','2022-10-17 18:19:58',NULL,NULL,NULL,NULL,NULL,104,'MAD',NULL,NULL,NULL),(978,'PM TANGER',NULL,NULL,'MA','2022-10-17 18:19:58','2022-10-17 18:19:59',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(979,'PMA TANGER',NULL,NULL,'MA','2022-10-17 18:19:59','2022-10-17 18:19:59',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(980,'PMA SIDI YAMANI',NULL,NULL,'MA','2022-10-17 18:19:59','2022-10-17 18:19:59',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(981,'PMA ASILAH',NULL,NULL,'MA','2022-10-17 18:19:59','2022-10-17 18:19:59',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(982,'PMA MELLOUSSA',NULL,NULL,'MA','2022-10-17 18:19:59','2022-10-17 18:20:00',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(983,'PMA GHDIR DAFLA',NULL,NULL,'MA','2022-10-17 18:20:00','2022-10-17 18:20:00',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(984,'BJ TANGER',NULL,NULL,'MA','2022-10-17 18:20:00','2022-10-17 18:20:00',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(985,'BD TANGER',NULL,NULL,'MA','2022-10-17 18:20:00','2022-10-17 18:20:00',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(986,'BT TANGER',NULL,NULL,'MA','2022-10-17 18:20:00','2022-10-17 18:20:00',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(987,'BT ASILAH',NULL,NULL,'MA','2022-10-17 18:20:00','2022-10-17 18:20:01',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(988,'BT DAR CHAOUI',NULL,NULL,'MA','2022-10-17 18:20:01','2022-10-17 18:20:01',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(989,'BT KSAR SEGHIR',NULL,NULL,'MA','2022-10-17 18:20:01','2022-10-17 18:20:01',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(990,'BT KHEMIS ANJRA',NULL,NULL,'MA','2022-10-17 18:20:01','2022-10-17 18:20:01',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(991,'BT MALLOUSSA',NULL,NULL,'MA','2022-10-17 18:20:01','2022-10-17 18:20:01',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(992,'BT KSAR EL MAJAZ',NULL,NULL,'MA','2022-10-17 18:20:01','2022-10-17 18:20:02',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(993,'BT GHARBIA',NULL,NULL,'MA','2022-10-17 18:20:02','2022-10-17 18:20:02',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(994,'BGTA BOUKHALEF',NULL,NULL,'MA','2022-10-17 18:20:02','2022-10-17 18:20:02',NULL,NULL,NULL,NULL,NULL,105,'MAD',NULL,NULL,NULL),(995,'BM TANGER',NULL,NULL,'MA','2022-10-17 18:20:02','2022-10-17 18:20:02',NULL,NULL,NULL,NULL,NULL,106,'MAD',NULL,NULL,NULL),(996,'BM LARACHE',NULL,NULL,'MA','2022-10-17 18:20:02','2022-10-17 18:20:02',NULL,NULL,NULL,NULL,NULL,106,'MAD',NULL,NULL,NULL),(997,'BM ASILAH',NULL,NULL,'MA','2022-10-17 18:20:02','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,106,'MAD',NULL,NULL,NULL),(998,'PM LARACHE',NULL,NULL,'MA','2022-10-17 18:20:03','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(999,'PMA LARACHE',NULL,NULL,'MA','2022-10-17 18:20:03','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1000,'BJ LARACHE',NULL,NULL,'MA','2022-10-17 18:20:03','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1001,'BD LARACHE',NULL,NULL,'MA','2022-10-17 18:20:03','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1002,'BT LARACHE',NULL,NULL,'MA','2022-10-17 18:20:03','2022-10-17 18:20:03',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1003,'BT LAOUAMRA',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:04',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1004,'BT KSAR EL KEBIR',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:04',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1005,'BT TATOFT',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:04',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1006,'BT KHEMISS SAHEL',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:04',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1007,'BT BNI AROUS',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:04',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1008,'BT BNI GUERFET',NULL,NULL,'MA','2022-10-17 18:20:04','2022-10-17 18:20:05',NULL,NULL,NULL,NULL,NULL,107,'MAD',NULL,NULL,NULL),(1009,'Bde Cyn TANGER MED',NULL,NULL,'MA','2022-10-17 18:20:05','2022-10-17 18:20:05',NULL,NULL,NULL,NULL,NULL,108,'MAD',NULL,NULL,NULL),(1010,'BM TANGER MED',NULL,NULL,'MA','2022-10-17 18:20:05','2022-10-17 18:20:05',NULL,NULL,NULL,NULL,NULL,108,'MAD',NULL,NULL,NULL),(1011,'BM 5 BASE NAVALE MARINE ROYALE',NULL,NULL,'MA','2022-10-17 18:20:05','2022-10-17 18:20:05',NULL,NULL,NULL,NULL,NULL,108,'MAD',NULL,NULL,NULL),(1012,'BSI TANGER MED',NULL,NULL,'MA','2022-10-17 18:20:05','2022-10-17 18:20:06',NULL,NULL,NULL,NULL,NULL,108,'MAD',NULL,NULL,NULL),(1013,'EMR AGADIR',NULL,NULL,NULL,'2022-10-17 18:47:39','2022-10-17 18:47:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1014,'EMR AL HOCEIMA',NULL,NULL,NULL,'2022-10-17 18:47:41','2022-10-17 18:47:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1015,'EMR BENI MELLAL',NULL,NULL,NULL,'2022-10-17 18:47:42','2022-10-17 18:47:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1016,'EMR BOUARFA',NULL,NULL,NULL,'2022-10-17 18:47:44','2022-10-17 18:47:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1017,'EMR CASABLANCA',NULL,NULL,NULL,'2022-10-17 18:47:45','2022-10-17 18:47:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1018,'EMR DAKHLA',NULL,NULL,NULL,'2022-10-17 18:47:47','2022-10-17 18:47:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1019,'EMR EL JADIDA',NULL,NULL,NULL,'2022-10-17 18:47:48','2022-10-17 18:47:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1020,'EMR ERRACHIDIA',NULL,NULL,NULL,'2022-10-17 18:47:48','2022-10-17 18:47:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1021,'EMR ESSAOUIRA',NULL,NULL,NULL,'2022-10-17 18:47:49','2022-10-17 18:47:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1022,'EMR FES',NULL,NULL,NULL,'2022-10-17 18:47:50','2022-10-17 18:47:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1023,'EMR GUELMIM',NULL,NULL,NULL,'2022-10-17 18:47:53','2022-10-17 18:47:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1024,'EMR KENITRA',NULL,NULL,NULL,'2022-10-17 18:47:54','2022-10-17 18:47:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1025,'EMR KHEMISSET',NULL,NULL,NULL,'2022-10-17 18:47:55','2022-10-17 18:47:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1026,'EMR KHENIFRA',NULL,NULL,NULL,'2022-10-17 18:47:55','2022-10-17 18:47:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1027,'EMR KHOURIBGA',NULL,NULL,NULL,'2022-10-17 18:47:56','2022-10-17 18:47:56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1028,'EMR LAAYOUNE',NULL,NULL,NULL,'2022-10-17 18:47:57','2022-10-17 18:47:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1029,'EMR MARRAKECH',NULL,NULL,NULL,'2022-10-17 18:47:58','2022-10-17 18:47:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1030,'EMR MEKNES',NULL,NULL,NULL,'2022-10-17 18:48:00','2022-10-17 18:48:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1031,'EMR NADOR',NULL,NULL,NULL,'2022-10-17 18:48:01','2022-10-17 18:48:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1032,'EMR OUARZAZATE',NULL,NULL,NULL,'2022-10-17 18:48:02','2022-10-17 18:48:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1033,'EMR OUJDA',NULL,NULL,NULL,'2022-10-17 18:48:02','2022-10-17 18:48:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1034,'EMR RABAT',NULL,NULL,NULL,'2022-10-17 18:48:04','2022-10-17 18:48:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1035,'EMR SAFI',NULL,NULL,NULL,'2022-10-17 18:48:05','2022-10-17 18:48:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1036,'EMR SETTAT',NULL,NULL,NULL,'2022-10-17 18:48:05','2022-10-17 18:48:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1037,'EMR SIDI KACEM',NULL,NULL,NULL,'2022-10-17 18:48:07','2022-10-17 18:48:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1038,'EMR TAZA',NULL,NULL,NULL,'2022-10-17 18:48:08','2022-10-17 18:48:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1039,'EMR TETOUAN',NULL,NULL,NULL,'2022-10-17 18:48:09','2022-10-17 18:48:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1040,'EMR TANGER',NULL,NULL,NULL,'2022-10-17 18:48:10','2022-10-17 18:48:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1041,'C.G.T.A NADOR - AL AAROUI',NULL,NULL,NULL,'2022-10-17 18:50:05','2022-10-17 18:56:04',NULL,NULL,NULL,NULL,NULL,1031,NULL,NULL,NULL,NULL),(1042,'Division Technique',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1043,'Division Production Audiovisuelle',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1044,'Division Presse et Revue',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1045,'SCCOM',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1046,'Secretariat et Coordination',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1047,'Cellule Soutien',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1046,NULL,NULL,NULL,NULL),(1048,'Section Maintenance',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1042,NULL,NULL,NULL,NULL),(1049,'Section Informatique',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1042,NULL,NULL,NULL,NULL),(1050,'Section Archivage',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1042,NULL,NULL,NULL,NULL),(1051,'Section Drones',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1042,NULL,NULL,NULL,NULL),(1052,'Section CPI',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1042,NULL,NULL,NULL,NULL),(1053,'Section Acquisition',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1043,NULL,NULL,NULL,NULL),(1054,'Section Realisation et Post-production',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1043,NULL,NULL,NULL,NULL),(1055,'Section Moyens de Production',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1043,NULL,NULL,NULL,NULL),(1056,'Section Revue',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:10',NULL,NULL,NULL,NULL,NULL,1044,NULL,NULL,NULL,NULL),(1057,'Section Veille et Analayse',NULL,NULL,NULL,'2022-10-21 09:31:10','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1044,NULL,NULL,NULL,NULL),(1058,'Section Événementiel',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1044,NULL,NULL,NULL,NULL),(1059,'Section Presse',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1044,NULL,NULL,NULL,NULL),(1060,'CFAV Benslimane',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1061,'Cellule Audiovisuelle Sala EL Jadida',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1045,NULL,NULL,NULL,NULL),(1062,'Secretariat et Personnel',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1046,NULL,NULL,NULL,NULL),(1063,'Comptabilite',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1047,NULL,NULL,NULL,NULL),(1064,'Parc Auto',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1047,NULL,NULL,NULL,NULL),(1065,'Service General',NULL,NULL,NULL,'2022-10-21 09:31:11','2022-10-21 09:31:11',NULL,NULL,NULL,NULL,NULL,1047,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `successful` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (1,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-17 17:36:47',NULL),(2,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-17 17:39:44',NULL),(3,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-19 17:52:22',NULL),(4,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-19 17:52:38',NULL),(5,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-21 09:17:15',NULL),(6,'mohcin.sarrar','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-21 10:42:45',NULL),(7,'mohcin.sarrar','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',0,'2022-10-21 14:26:17',NULL),(8,'mohcin.sarrar','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',0,'2022-10-21 14:26:39',NULL),(9,'mohcin.sarrar','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-21 14:27:23',NULL),(10,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-22 22:13:28',NULL),(11,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-22 22:14:12',NULL),(12,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',1,'2022-10-22 23:25:49',NULL),(13,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',1,'2022-10-31 15:50:40',NULL),(14,'hamza.elfaidi','192.168.91.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',1,'2022-10-31 15:51:56',NULL),(15,'hamza.elfaidi','172.17.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',1,'2022-11-02 11:54:29',NULL),(16,'hamza.elfaidi','172.17.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',1,'2022-11-02 11:54:37',NULL),(17,'hamza.elfaidi','172.17.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',1,'2022-11-02 17:38:55',NULL);
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `manufacturers` WRITE;
/*!40000 ALTER TABLE `manufacturers` DISABLE KEYS */;
INSERT INTO `manufacturers` VALUES (1,'SONY','2022-10-21 08:43:19','2022-10-21 08:43:19',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-PsTqxaENtP.png'),(2,'CANON','2022-10-21 08:43:32','2022-10-21 08:43:32',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-poUYrX7HBv.png'),(3,'LENONO','2022-10-21 08:43:45','2022-10-21 08:43:45',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-afro7GkRPG.png'),(4,'EATON','2022-10-21 08:43:58','2022-10-21 08:43:58',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-8UfAA5whVM.png'),(5,'XEROX','2022-10-21 08:44:12','2022-10-21 08:44:12',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-1tUEoJnLs9.png'),(6,'SHURE','2022-10-21 08:44:22','2022-10-21 08:44:22',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-n2jeMgQVEt.svg'),(7,'BEYERDYNAMIQUE','2022-10-21 08:44:51','2022-10-21 08:44:51',1,NULL,NULL,NULL,NULL,NULL,'manufacturer-image-pcfOtD1iT8.svg');
/*!40000 ALTER TABLE `manufacturers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2012_12_06_225921_migration_cartalyst_sentry_install_users',1),(2,'2012_12_06_225929_migration_cartalyst_sentry_install_groups',1),(3,'2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot',1),(4,'2012_12_06_225988_migration_cartalyst_sentry_install_throttle',1),(5,'2013_03_23_193214_update_users_table',1),(6,'2013_11_13_075318_create_models_table',1),(7,'2013_11_13_075335_create_categories_table',1),(8,'2013_11_13_075347_create_manufacturers_table',1),(9,'2013_11_15_015858_add_user_id_to_categories',1),(10,'2013_11_15_112701_add_user_id_to_manufacturers',1),(11,'2013_11_15_190327_create_assets_table',1),(12,'2013_11_15_190357_create_temp_licenses_table',1),(13,'2013_11_15_201848_add_license_name_to_licenses',1),(14,'2013_11_16_040323_create_depreciations_table',1),(15,'2013_11_16_042851_add_depreciation_id_to_models',1),(16,'2013_11_16_084923_add_user_id_to_models',1),(17,'2013_11_16_103258_create_locations_table',1),(18,'2013_11_16_103336_add_location_id_to_assets',1),(19,'2013_11_16_103407_add_checkedout_to_to_assets',1),(20,'2013_11_16_103425_create_history_table',1),(21,'2013_11_17_054359_drop_licenses_table',1),(22,'2013_11_17_054526_add_physical_to_assets',1),(23,'2013_11_17_055126_create_settings_table',1),(24,'2013_11_17_062634_add_license_to_assets',1),(25,'2013_11_18_134332_add_contacts_to_users',1),(26,'2013_11_18_142847_add_info_to_locations',1),(27,'2013_11_18_152942_remove_location_id_from_asset',1),(28,'2013_11_18_164423_set_nullvalues_for_user',1),(29,'2013_11_19_013337_create_asset_logs_table',1),(30,'2013_11_19_061409_edit_added_on_asset_logs_table',1),(31,'2013_11_19_062250_edit_location_id_asset_logs_table',1),(32,'2013_11_20_055822_add_soft_delete_on_assets',1),(33,'2013_11_20_121404_add_soft_delete_on_locations',1),(34,'2013_11_20_123137_add_soft_delete_on_manufacturers',1),(35,'2013_11_20_123725_add_soft_delete_on_categories',1),(36,'2013_11_20_130248_create_status_labels',1),(37,'2013_11_20_130830_add_status_id_on_assets_table',1),(38,'2013_11_20_131544_add_status_type_on_status_labels',1),(39,'2013_11_20_134103_add_archived_to_assets',1),(40,'2013_11_21_002321_add_uploads_table',1),(41,'2013_11_21_024531_remove_deployable_boolean_from_status_labels',1),(42,'2013_11_22_075308_add_option_label_to_settings_table',1),(43,'2013_11_22_213400_edits_to_settings_table',1),(44,'2013_11_25_013244_recreate_licenses_table',1),(45,'2013_11_25_031458_create_license_seats_table',1),(46,'2013_11_25_032022_add_type_to_actionlog_table',1),(47,'2013_11_25_033008_delete_bad_licenses_table',1),(48,'2013_11_25_033131_create_new_licenses_table',1),(49,'2013_11_25_033534_add_licensed_to_licenses_table',1),(50,'2013_11_25_101308_add_warrantee_to_assets_table',1),(51,'2013_11_25_104343_alter_warranty_column_on_assets',1),(52,'2013_11_25_150450_drop_parent_from_categories',1),(53,'2013_11_25_151920_add_depreciate_to_assets',1),(54,'2013_11_25_152903_add_depreciate_to_licenses_table',1),(55,'2013_11_26_211820_drop_license_from_assets_table',1),(56,'2013_11_27_062510_add_note_to_asset_logs_table',1),(57,'2013_12_01_113426_add_filename_to_asset_log',1),(58,'2013_12_06_094618_add_nullable_to_licenses_table',1),(59,'2013_12_10_084038_add_eol_on_models_table',1),(60,'2013_12_12_055218_add_manager_to_users_table',1),(61,'2014_01_28_031200_add_qr_code_to_settings_table',1),(62,'2014_02_13_183016_add_qr_text_to_settings_table',1),(63,'2014_05_24_093839_alter_default_license_depreciation_id',1),(64,'2014_05_27_231658_alter_default_values_licenses',1),(65,'2014_06_19_191508_add_asset_name_to_settings',1),(66,'2014_06_20_004847_make_asset_log_checkedout_to_nullable',1),(67,'2014_06_20_005050_make_asset_log_purchasedate_to_nullable',1),(68,'2014_06_24_003011_add_suppliers',1),(69,'2014_06_24_010742_add_supplier_id_to_asset',1),(70,'2014_06_24_012839_add_zip_to_supplier',1),(71,'2014_06_24_033908_add_url_to_supplier',1),(72,'2014_07_08_054116_add_employee_id_to_users',1),(73,'2014_07_09_134316_add_requestable_to_assets',1),(74,'2014_07_17_085822_add_asset_to_software',1),(75,'2014_07_17_161625_make_asset_id_in_logs_nullable',1),(76,'2014_08_12_053504_alpha_0_4_2_release',1),(77,'2014_08_17_083523_make_location_id_nullable',1),(78,'2014_10_16_200626_add_rtd_location_to_assets',1),(79,'2014_10_24_000417_alter_supplier_state_to_32',1),(80,'2014_10_24_015641_add_display_checkout_date',1),(81,'2014_10_28_222654_add_avatar_field_to_users_table',1),(82,'2014_10_29_045924_add_image_field_to_models_table',1),(83,'2014_11_01_214955_add_eol_display_to_settings',1),(84,'2014_11_04_231416_update_group_field_for_reporting',1),(85,'2014_11_05_212408_add_fields_to_licenses',1),(86,'2014_11_07_021042_add_image_to_supplier',1),(87,'2014_11_20_203007_add_username_to_user',1),(88,'2014_11_20_223947_add_auto_to_settings',1),(89,'2014_11_20_224421_add_prefix_to_settings',1),(90,'2014_11_21_104401_change_licence_type',1),(91,'2014_12_09_082500_add_fields_maintained_term_to_licenses',1),(92,'2015_02_04_155757_increase_user_field_lengths',1),(93,'2015_02_07_013537_add_soft_deleted_to_log',1),(94,'2015_02_10_040958_fix_bad_assigned_to_ids',1),(95,'2015_02_10_053310_migrate_data_to_new_statuses',1),(96,'2015_02_11_044104_migrate_make_license_assigned_null',1),(97,'2015_02_11_104406_migrate_create_requests_table',1),(98,'2015_02_12_001312_add_mac_address_to_asset',1),(99,'2015_02_12_024100_change_license_notes_type',1),(100,'2015_02_17_231020_add_localonly_to_settings',1),(101,'2015_02_19_222322_add_logo_and_colors_to_settings',1),(102,'2015_02_24_072043_add_alerts_to_settings',1),(103,'2015_02_25_022931_add_eula_fields',1),(104,'2015_02_25_204513_add_accessories_table',1),(105,'2015_02_26_091228_add_accessories_user_table',1),(106,'2015_02_26_115128_add_deleted_at_models',1),(107,'2015_02_26_233005_add_category_type',1),(108,'2015_03_01_231912_update_accepted_at_to_acceptance_id',1),(109,'2015_03_05_011929_add_qr_type_to_settings',1),(110,'2015_03_18_055327_add_note_to_user',1),(111,'2015_04_29_234704_add_slack_to_settings',1),(112,'2015_05_04_085151_add_parent_id_to_locations_table',1),(113,'2015_05_22_124421_add_reassignable_to_licenses',1),(114,'2015_06_10_003314_fix_default_for_user_notes',1),(115,'2015_06_10_003554_create_consumables',1),(116,'2015_06_15_183253_move_email_to_username',1),(117,'2015_06_23_070346_make_email_nullable',1),(118,'2015_06_26_213716_create_asset_maintenances_table',1),(119,'2015_07_04_212443_create_custom_fields_table',1),(120,'2015_07_09_014359_add_currency_to_settings_and_locations',1),(121,'2015_07_21_122022_add_expected_checkin_date_to_asset_logs',1),(122,'2015_07_24_093845_add_checkin_email_to_category_table',1),(123,'2015_07_25_055415_remove_email_unique_constraint',1),(124,'2015_07_29_230054_add_thread_id_to_asset_logs_table',1),(125,'2015_07_31_015430_add_accepted_to_assets',1),(126,'2015_09_09_195301_add_custom_css_to_settings',1),(127,'2015_09_21_235926_create_custom_field_custom_fieldset',1),(128,'2015_09_22_000104_create_custom_fieldsets',1),(129,'2015_09_22_003321_add_fieldset_id_to_assets',1),(130,'2015_09_22_003413_migrate_mac_address',1),(131,'2015_09_28_003314_fix_default_purchase_order',1),(132,'2015_10_01_024551_add_accessory_consumable_price_info',1),(133,'2015_10_12_192706_add_brand_to_settings',1),(134,'2015_10_22_003314_fix_defaults_accessories',1),(135,'2015_10_23_182625_add_checkout_time_and_expected_checkout_date_to_assets',1),(136,'2015_11_05_061015_create_companies_table',1),(137,'2015_11_05_061115_add_company_id_to_consumables_table',1),(138,'2015_11_05_183749_image',1),(139,'2015_11_06_092038_add_company_id_to_accessories_table',1),(140,'2015_11_06_100045_add_company_id_to_users_table',1),(141,'2015_11_06_134742_add_company_id_to_licenses_table',1),(142,'2015_11_08_035832_add_company_id_to_assets_table',1),(143,'2015_11_08_222305_add_ldap_fields_to_settings',1),(144,'2015_11_15_151803_add_full_multiple_companies_support_to_settings_table',1),(145,'2015_11_26_195528_import_ldap_settings',1),(146,'2015_11_30_191504_remove_fk_company_id',1),(147,'2015_12_21_193006_add_ldap_server_cert_ignore_to_settings_table',1),(148,'2015_12_30_233509_add_timestamp_and_userId_to_custom_fields',1),(149,'2015_12_30_233658_add_timestamp_and_userId_to_custom_fieldsets',1),(150,'2016_01_28_041048_add_notes_to_models',1),(151,'2016_02_19_070119_add_remember_token_to_users_table',1),(152,'2016_02_19_073625_create_password_resets_table',1),(153,'2016_03_02_193043_add_ldap_flag_to_users',1),(154,'2016_03_02_220517_update_ldap_filter_to_longer_field',1),(155,'2016_03_08_225351_create_components_table',1),(156,'2016_03_09_024038_add_min_stock_to_tables',1),(157,'2016_03_10_133849_add_locale_to_users',1),(158,'2016_03_10_135519_add_locale_to_settings',1),(159,'2016_03_11_185621_add_label_settings_to_settings',1),(160,'2016_03_22_125911_fix_custom_fields_regexes',1),(161,'2016_04_28_141554_add_show_to_users',1),(162,'2016_05_16_164733_add_model_mfg_to_consumable',1),(163,'2016_05_19_180351_add_alt_barcode_settings',1),(164,'2016_05_19_191146_add_alter_interval',1),(165,'2016_05_19_192226_add_inventory_threshold',1),(166,'2016_05_20_024859_remove_option_keys_from_settings_table',1),(167,'2016_05_20_143758_remove_option_value_from_settings_table',1),(168,'2016_06_01_000001_create_oauth_auth_codes_table',1),(169,'2016_06_01_000002_create_oauth_access_tokens_table',1),(170,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(171,'2016_06_01_000004_create_oauth_clients_table',1),(172,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(173,'2016_06_01_140218_add_email_domain_and_format_to_settings',1),(174,'2016_06_22_160725_add_user_id_to_maintenances',1),(175,'2016_07_13_150015_add_is_ad_to_settings',1),(176,'2016_07_14_153609_add_ad_domain_to_settings',1),(177,'2016_07_22_003348_fix_custom_fields_regex_stuff',1),(178,'2016_07_22_054850_one_more_mac_addr_fix',1),(179,'2016_07_22_143045_add_port_to_ldap_settings',1),(180,'2016_07_22_153432_add_tls_to_ldap_settings',1),(181,'2016_07_27_211034_add_zerofill_to_settings',1),(182,'2016_08_02_124944_add_color_to_statuslabel',1),(183,'2016_08_04_134500_add_disallow_ldap_pw_sync_to_settings',1),(184,'2016_08_09_002225_add_manufacturer_to_licenses',1),(185,'2016_08_12_121613_add_manufacturer_to_accessories_table',1),(186,'2016_08_23_143353_add_new_fields_to_custom_fields',1),(187,'2016_08_23_145619_add_show_in_nav_to_status_labels',1),(188,'2016_08_30_084634_make_purchase_cost_nullable',1),(189,'2016_09_01_141051_add_requestable_to_asset_model',1),(190,'2016_09_02_001448_create_checkout_requests_table',1),(191,'2016_09_04_180400_create_actionlog_table',1),(192,'2016_09_04_182149_migrate_asset_log_to_action_log',1),(193,'2016_09_19_235935_fix_fieldtype_for_target_type',1),(194,'2016_09_23_140722_fix_modelno_in_consumables_to_string',1),(195,'2016_09_28_231359_add_company_to_logs',1),(196,'2016_10_14_130709_fix_order_number_to_varchar',1),(197,'2016_10_16_015024_rename_modelno_to_model_number',1),(198,'2016_10_16_015211_rename_consumable_modelno_to_model_number',1),(199,'2016_10_16_143235_rename_model_note_to_notes',1),(200,'2016_10_16_165052_rename_component_total_qty_to_qty',1),(201,'2016_10_19_145520_fix_order_number_in_components_to_string',1),(202,'2016_10_27_151715_add_serial_to_components',1),(203,'2016_10_27_213251_increase_serial_field_capacity',1),(204,'2016_10_29_002724_enable_2fa_fields',1),(205,'2016_10_29_082408_add_signature_to_acceptance',1),(206,'2016_11_01_030818_fix_forgotten_filename_in_action_logs',1),(207,'2016_11_13_020954_rename_component_serial_number_to_serial',1),(208,'2016_11_16_172119_increase_purchase_cost_size',1),(209,'2016_11_17_161317_longer_state_field_in_location',1),(210,'2016_11_17_193706_add_model_number_to_accessories',1),(211,'2016_11_24_160405_add_missing_target_type_to_logs_table',1),(212,'2016_12_07_173720_increase_size_of_state_in_suppliers',1),(213,'2016_12_19_004212_adjust_locale_length_to_10',1),(214,'2016_12_19_133936_extend_phone_lengths_in_supplier_and_elsewhere',1),(215,'2016_12_27_212631_make_asset_assigned_to_polymorphic',1),(216,'2017_01_09_040429_create_locations_ldap_query_field',1),(217,'2017_01_14_002418_create_imports_table',1),(218,'2017_01_25_063357_fix_utf8_custom_field_column_names',1),(219,'2017_03_03_154632_add_time_date_display_to_settings',1),(220,'2017_03_10_210807_add_fields_to_manufacturer',1),(221,'2017_05_08_195520_increase_size_of_field_values_in_custom_fields',1),(222,'2017_05_22_204422_create_departments',1),(223,'2017_05_22_233509_add_manager_to_locations_table',1),(224,'2017_06_14_122059_add_next_autoincrement_to_settings',1),(225,'2017_06_18_151753_add_header_and_first_row_to_importer_table',1),(226,'2017_07_07_191533_add_login_text',1),(227,'2017_07_25_130710_add_thumbsize_to_settings',1),(228,'2017_08_03_160105_set_asset_archived_to_zero_default',1),(229,'2017_08_22_180636_add_secure_password_options',1),(230,'2017_08_25_074822_add_auditing_tables',1),(231,'2017_08_25_101435_add_auditing_to_settings',1),(232,'2017_09_18_225619_fix_assigned_type_not_being_nulled',1),(233,'2017_10_03_015503_drop_foreign_keys',1),(234,'2017_10_10_123504_allow_nullable_depreciation_id_in_models',1),(235,'2017_10_17_133709_add_display_url_to_settings',1),(236,'2017_10_19_120002_add_custom_forgot_password_url',1),(237,'2017_10_19_130406_add_image_and_supplier_to_accessories',1),(238,'2017_10_20_234129_add_location_indices_to_assets',1),(239,'2017_10_25_202930_add_images_uploads_to_locations_manufacturers_etc',1),(240,'2017_10_27_180947_denorm_asset_locations',1),(241,'2017_10_27_192423_migrate_denormed_asset_locations',1),(242,'2017_10_30_182938_add_address_to_user',1),(243,'2017_11_08_025918_add_alert_menu_setting',1),(244,'2017_11_08_123942_labels_display_company_name',1),(245,'2017_12_12_010457_normalize_asset_last_audit_date',1),(246,'2017_12_12_033618_add_actionlog_meta',1),(247,'2017_12_26_170856_re_normalize_last_audit',1),(248,'2018_01_17_184354_add_archived_in_list_setting',1),(249,'2018_01_19_203121_add_dashboard_message_to_settings',1),(250,'2018_01_24_062633_add_footer_settings_to_settings',1),(251,'2018_01_24_093426_add_modellist_preferenc',1),(252,'2018_02_22_160436_add_remote_user_settings',1),(253,'2018_03_03_011032_add_theme_to_settings',1),(254,'2018_03_06_054937_add_default_flag_on_statuslabels',1),(255,'2018_03_23_212048_add_display_in_email_to_custom_fields',1),(256,'2018_03_24_030738_add_show_images_in_email_setting',1),(257,'2018_03_24_050108_add_cc_alerts',1),(258,'2018_03_29_053618_add_canceled_at_and_fulfilled_at_in_requests',1),(259,'2018_03_29_070121_add_drop_unique_requests',1),(260,'2018_03_29_070511_add_new_index_requestable',1),(261,'2018_04_02_150700_labels_display_model_name',1),(262,'2018_04_16_133902_create_custom_field_default_values_table',1),(263,'2018_05_04_073223_add_category_to_licenses',1),(264,'2018_05_04_075235_add_update_license_category',1),(265,'2018_05_08_031515_add_gdpr_privacy_footer',1),(266,'2018_05_14_215229_add_indexes',1),(267,'2018_05_14_223646_add_indexes_to_assets',1),(268,'2018_05_14_233638_denorm_counters_on_assets',1),(269,'2018_05_16_153409_add_first_counter_totals_to_assets',1),(270,'2018_06_21_134622_add_version_footer',1),(271,'2018_07_05_215440_add_unique_serial_option_to_settings',1),(272,'2018_07_17_005911_create_login_attempts_table',1),(273,'2018_07_24_154348_add_logo_to_print_assets',1),(274,'2018_07_28_023826_create_checkout_acceptances_table',1),(275,'2018_08_20_204842_add_depreciation_option_to_settings',1),(276,'2018_09_10_082212_create_checkout_acceptances_for_unaccepted_assets',1),(277,'2018_10_18_191228_add_kits_licenses_table',1),(278,'2018_10_19_153910_add_kits_table',1),(279,'2018_10_19_154013_add_kits_models_table',1),(280,'2018_12_05_211936_add_favicon_to_settings',1),(281,'2018_12_05_212119_add_email_logo_to_settings',1),(282,'2019_02_07_185953_add_kits_consumables_table',1),(283,'2019_02_07_190030_add_kits_accessories_table',1),(284,'2019_02_12_182750_add_actiondate_to_actionlog',1),(285,'2019_02_14_154310_change_auto_increment_prefix_to_nullable',1),(286,'2019_02_16_143518_auto_increment_back_to_string',1),(287,'2019_02_17_205048_add_label_logo_to_settings',1),(288,'2019_02_20_234421_make_serial_nullable',1),(289,'2019_02_21_224703_make_fields_nullable_for_integrity',1),(290,'2019_04_06_060145_add_user_skin_setting',1),(291,'2019_04_06_205355_add_setting_allow_user_skin',1),(292,'2019_06_12_184327_rename_groups_table',1),(293,'2019_07_23_140906_add_show_assigned_assets_to_settings',1),(294,'2019_08_20_084049_add_custom_remote_user_header',1),(295,'2019_12_04_223111_passport_upgrade',1),(296,'2020_02_04_172100_add_ad_append_domain_settings',1),(297,'2020_04_29_222305_add_saml_fields_to_settings',1),(298,'2020_08_11_200712_add_saml_key_rollover',1),(299,'2020_10_22_233743_move_accessory_checkout_note_to_join_table',1),(300,'2020_10_23_161736_fix_zero_values_for_locations',1),(301,'2020_11_18_214827_widen_license_serial_field',1),(302,'2020_12_14_233815_add_digit_separator_to_settings',1),(303,'2020_12_18_090026_swap_target_type_index_order',1),(304,'2020_12_21_153235_update_min_password',1),(305,'2020_12_21_210105_fix_bad_ldap_server_url_for_v5',1),(306,'2021_02_05_172502_add_provider_to_oauth_table',1),(307,'2021_03_18_184102_adds_several_ldap_fields',1),(308,'2021_04_07_001811_add_ldap_dept',1),(309,'2021_04_14_180125_add_ids_to_tables',1),(310,'2021_06_07_155421_add_serial_number_indexes',1),(311,'2021_06_07_155436_add_company_id_indexes',1),(312,'2021_07_28_031345_add_client_side_l_d_a_p_cert_to_settings',1),(313,'2021_07_28_040554_add_client_side_l_d_a_p_key_to_settings',1),(314,'2021_08_11_005206_add_depreciation_minimum_value',1),(315,'2021_08_24_124354_make_ldap_client_certs_nullable',1),(316,'2021_09_20_183216_change_default_label_to_nullable',1),(317,'2021_12_27_151849_change_supplier_address_length',1),(318,'2022_01_10_182548_add_license_id_index_to_license_seats',1),(319,'2022_02_03_214958_blank_out_ldap_active_flag',1),(320,'2022_02_16_152431_add_unique_constraint_to_custom_field',1),(321,'2022_03_03_225655_add_notes_to_accessories',1),(322,'2022_03_03_225754_add_notes_to_components',1),(323,'2022_03_03_225824_add_notes_to_consumables',1),(324,'2022_03_04_080836_add_remote_to_user',1),(325,'2022_03_09_001334_add_eula_to_checkout_acceptance',1),(326,'2022_03_10_175740_add_eula_to_action_logs',1),(327,'2022_03_21_162724_adds_ldap_manager',1),(328,'2022_04_05_135340_add_primary_key_to_custom_fields_pivot',1),(329,'2022_05_16_235350_remove_stored_eula_field',1),(330,'2022_06_23_164407_add_user_id_to_users',1),(331,'2022_06_28_234539_add_username_index_to_users',1),(332,'2022_07_07_010406_add_indexes_to_license_seats',1),(333,'2022_08_10_141328_add_notes_denorm_to_consumables_users',1),(334,'2022_09_29_040231_add_chart_type_to_settings',1),(335,'2022_10_05_163044_add_start_termination_date_to_users',1),(336,'2022_10_25_193823_add_externalid_to_users',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `depreciation_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `eol` int(11) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deprecated_mac_address` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `fieldset_id` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `requestable` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'XDCAM','PXW-X160',1,5,'2022-10-21 08:54:22','2022-10-21 08:54:22',NULL,1,0,'assetmodel-image-1SoYz6QqSh.webp',0,NULL,NULL,NULL,0),(2,'Thinkstation','P350',3,10,'2022-10-21 08:55:47','2022-10-21 08:55:47',NULL,1,0,'assetmodel-image-KxL7mifVMz.png',0,NULL,NULL,NULL,0),(3,'Souris Lenovo Essential','4Y50R20863',3,2,'2022-10-21 08:57:38','2022-10-21 09:00:00',NULL,1,0,'assetmodel-image-AcKhtOYBio.jpg',0,NULL,NULL,NULL,0),(4,'Clavier Lenovo Essential',NULL,3,3,'2022-10-21 09:03:55','2022-10-21 09:03:55',NULL,1,0,'assetmodel-image-7i7uPd907i.png',0,NULL,NULL,NULL,0),(5,'Thinkvision E24-28','62C7MAR4WW',3,8,'2022-10-21 09:08:24','2022-10-21 09:08:24',NULL,1,0,'assetmodel-image-GlkXmW3kd1.jpg',0,NULL,NULL,NULL,0),(6,'Onduleur 500VA ','5E 650i',4,9,'2022-10-21 09:09:35','2022-10-21 09:09:35',NULL,1,0,'assetmodel-image-MhPIR596cC.jpg',0,NULL,NULL,NULL,0),(7,'Imprimante Xerox','Phaser 7800DN',5,6,'2022-10-21 09:10:24','2022-10-21 09:10:24',NULL,1,0,'assetmodel-image-Jyn35cKrgA.png',0,NULL,NULL,NULL,0),(8,'Micro Dynamique','SM48 LC',6,7,'2022-10-21 09:11:39','2022-10-21 09:11:39',NULL,1,0,'assetmodel-image-GUv3nwQdwT.webp',0,NULL,NULL,NULL,0),(9,'Micro Beyerdynamique','M69',7,7,'2022-10-21 09:12:44','2022-10-21 09:12:44',NULL,1,0,'assetmodel-image-zw0fTowigS.webp',0,NULL,NULL,NULL,0),(10,'Canon EOS','5D MARCK III',2,4,'2022-10-21 09:14:26','2022-10-21 09:14:26',NULL,1,0,'assetmodel-image-JjVlSNjAC1.png',0,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `models_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models_custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_model_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `default_value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `models_custom_fields` WRITE;
/*!40000 ALTER TABLE `models_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `models_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('55e26714f3a5b148b510eb194c222f27cab383a5e7ac8f0eeb79eb613a1a8938bd8037035cf823bb',1,1,'Power BI','[]',1,'2022-10-22 21:19:01','2022-10-22 21:19:01','2037-10-22 22:19:01'),('9174c9902e18d62cdf6976fd5ae8cea6c841e641a0fbd1648055d33f76edd25f74cde640b361f027',1,1,'Power BI','[]',0,'2022-10-22 23:26:04','2022-10-22 23:26:04','2037-10-23 00:26:04'),('cf8979f111d31e5117aaa48ce0778eb0fdf0684d4e268da70e4b85f3635efde5c15808c779e002b8',1,1,'Power BI','[]',1,'2022-10-22 22:14:39','2022-10-22 22:14:39','2037-10-22 23:14:39');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'SCCOM Personal Access Client','5KWE6HejpP8FKe8sFQeDP97kuAusFynGYus70aaR',NULL,'http://localhost',1,0,0,'2022-10-22 21:18:42','2022-10-22 21:18:42'),(2,NULL,'SCCOM Password Grant Client','FB30kwYVd160Q9sftp7T4qL2ZqPhEsCdWqXhdLKx','users','http://localhost',0,1,0,'2022-10-22 21:18:42','2022-10-22 21:18:42');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2022-10-22 21:18:42','2022-10-22 21:18:42');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permission_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permission_groups` WRITE;
/*!40000 ALTER TABLE `permission_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `requested_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requested_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `denied_at` datetime DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `requested_assets` WRITE;
/*!40000 ALTER TABLE `requested_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `requested_assets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `request_code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `per_page` int(11) NOT NULL DEFAULT '20',
  `site_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Snipe IT Asset Management',
  `qr_code` int(11) DEFAULT NULL,
  `qr_text` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_asset_name` int(11) DEFAULT NULL,
  `display_checkout_date` int(11) DEFAULT NULL,
  `display_eol` int(11) DEFAULT NULL,
  `auto_increment_assets` int(11) NOT NULL DEFAULT '0',
  `auto_increment_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `load_remote` tinyint(1) NOT NULL DEFAULT '1',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `header_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alert_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `default_eula_text` longtext COLLATE utf8mb4_unicode_ci,
  `barcode_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'QRCODE',
  `slack_endpoint` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slack_channel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slack_botname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_css` text COLLATE utf8mb4_unicode_ci,
  `brand` tinyint(4) NOT NULL DEFAULT '1',
  `ldap_enabled` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_server` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_uname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_pword` longtext COLLATE utf8mb4_unicode_ci,
  `ldap_basedn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_filter` text COLLATE utf8mb4_unicode_ci,
  `ldap_username_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'samaccountname',
  `ldap_lname_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'sn',
  `ldap_fname_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'givenname',
  `ldap_auth_filter_query` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'uid=',
  `ldap_version` int(11) DEFAULT '3',
  `ldap_active_flag` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_dept` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_emp_num` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_phone_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_jobtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_manager` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_multiple_companies_support` tinyint(1) NOT NULL DEFAULT '0',
  `ldap_server_cert_ignore` tinyint(1) NOT NULL DEFAULT '0',
  `locale` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT 'fr',
  `labels_per_page` tinyint(4) NOT NULL DEFAULT '30',
  `labels_width` decimal(6,5) NOT NULL DEFAULT '2.62500',
  `labels_height` decimal(6,5) NOT NULL DEFAULT '1.00000',
  `labels_pmargin_left` decimal(6,5) NOT NULL DEFAULT '0.21975',
  `labels_pmargin_right` decimal(6,5) NOT NULL DEFAULT '0.21975',
  `labels_pmargin_top` decimal(6,5) NOT NULL DEFAULT '0.50000',
  `labels_pmargin_bottom` decimal(6,5) NOT NULL DEFAULT '0.50000',
  `labels_display_bgutter` decimal(6,5) NOT NULL DEFAULT '0.07000',
  `labels_display_sgutter` decimal(6,5) NOT NULL DEFAULT '0.05000',
  `labels_fontsize` tinyint(4) NOT NULL DEFAULT '9',
  `labels_pagewidth` decimal(7,5) NOT NULL DEFAULT '8.50000',
  `labels_pageheight` decimal(7,5) NOT NULL DEFAULT '11.00000',
  `labels_display_name` tinyint(4) NOT NULL DEFAULT '0',
  `labels_display_serial` tinyint(4) NOT NULL DEFAULT '1',
  `labels_display_tag` tinyint(4) NOT NULL DEFAULT '1',
  `alt_barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'C128',
  `alt_barcode_enabled` tinyint(1) DEFAULT '1',
  `alert_interval` int(11) DEFAULT '30',
  `alert_threshold` int(11) DEFAULT '5',
  `email_domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'filastname',
  `username_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'filastname',
  `is_ad` tinyint(1) NOT NULL DEFAULT '0',
  `ad_domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldap_port` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '389',
  `ldap_tls` tinyint(1) NOT NULL DEFAULT '0',
  `zerofill_count` int(11) NOT NULL DEFAULT '5',
  `ldap_pw_sync` tinyint(1) NOT NULL DEFAULT '1',
  `two_factor_enabled` tinyint(4) DEFAULT NULL,
  `require_accept_signature` tinyint(1) NOT NULL DEFAULT '0',
  `date_display_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y-m-d',
  `time_display_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'h:i A',
  `next_auto_tag_base` bigint(20) NOT NULL DEFAULT '1',
  `login_note` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_max_h` int(11) DEFAULT '50',
  `pwd_secure_uncommon` tinyint(1) NOT NULL DEFAULT '0',
  `pwd_secure_complexity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pwd_secure_min` int(11) NOT NULL DEFAULT '8',
  `audit_interval` int(11) DEFAULT NULL,
  `audit_warning_days` int(11) DEFAULT NULL,
  `show_url_in_emails` tinyint(1) NOT NULL DEFAULT '0',
  `custom_forgot_pass_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_alerts_in_menu` tinyint(1) NOT NULL DEFAULT '1',
  `labels_display_company_name` tinyint(1) NOT NULL DEFAULT '0',
  `show_archived_in_list` tinyint(1) NOT NULL DEFAULT '0',
  `dashboard_message` text COLLATE utf8mb4_unicode_ci,
  `support_footer` char(5) COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `footer_text` text COLLATE utf8mb4_unicode_ci,
  `modellist_displays` char(191) COLLATE utf8mb4_unicode_ci DEFAULT 'image,category,manufacturer,model_number',
  `login_remote_user_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `login_common_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `login_remote_user_custom_logout_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skin` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_images_in_email` tinyint(1) NOT NULL DEFAULT '1',
  `admin_cc_email` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labels_display_model` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_policy_link` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_footer` char(5) COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `unique_serial` tinyint(1) NOT NULL DEFAULT '0',
  `logo_print_assets` tinyint(1) NOT NULL DEFAULT '0',
  `depreciation_method` char(10) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `favicon` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_logo` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label_logo` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_user_skin` tinyint(1) NOT NULL DEFAULT '0',
  `show_assigned_assets` tinyint(1) NOT NULL DEFAULT '0',
  `login_remote_user_header_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ad_append_domain` tinyint(1) NOT NULL DEFAULT '0',
  `saml_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `saml_idp_metadata` text COLLATE utf8mb4_unicode_ci,
  `saml_attr_mapping_username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saml_forcelogin` tinyint(1) NOT NULL DEFAULT '0',
  `saml_slo` tinyint(1) NOT NULL DEFAULT '0',
  `saml_sp_x509cert` text COLLATE utf8mb4_unicode_ci,
  `saml_sp_privatekey` text COLLATE utf8mb4_unicode_ci,
  `saml_custom_settings` text COLLATE utf8mb4_unicode_ci,
  `saml_sp_x509certNew` text COLLATE utf8mb4_unicode_ci,
  `digit_separator` char(191) COLLATE utf8mb4_unicode_ci DEFAULT '1,234.56',
  `ldap_client_tls_cert` text COLLATE utf8mb4_unicode_ci,
  `ldap_client_tls_key` text COLLATE utf8mb4_unicode_ci,
  `dash_chart_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'name',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'2022-10-17 17:36:47','2022-11-02 17:47:29',1,20,'SCCOM - Inventaire',1,NULL,NULL,NULL,NULL,1,NULL,1,'setting-logo-wxDyRBs2bF.png',NULL,'hamza.elfaidi@sccom.gr',1,NULL,'QRCODE',NULL,NULL,NULL,'MAD',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,'samaccountname','sn','givenname','uid=',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'fr',30,2.62500,1.00000,0.21975,0.21975,0.50000,0.50000,0.07000,0.05000,9,8.50000,11.00000,0,1,1,'C128',1,30,5,'sccom.gr','firstnamelastname','filastname',0,NULL,'389',0,5,1,NULL,0,'d/m/Y','H:i',3,NULL,50,0,NULL,10,NULL,NULL,0,NULL,1,0,0,NULL,'off',NULL,'image,category,manufacturer,model_number',0,0,'','blue',1,NULL,0,NULL,'off',0,1,'default',NULL,'setting-email_logo-5ymPKnKdFc.png','setting-label_logo-BwgS58betC.png',0,0,'',0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,'1,234.56',NULL,NULL,'name');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_labels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deployable` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_in_nav` tinyint(1) DEFAULT '0',
  `default_label` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `status_labels` WRITE;
/*!40000 ALTER TABLE `status_labels` DISABLE KEYS */;
INSERT INTO `status_labels` VALUES (1,'Pending',1,NULL,NULL,NULL,0,1,0,'These assets are not yet ready to be deployed, usually because of configuration or waiting on parts.',NULL,0,0),(2,'Ready to Deploy',1,NULL,NULL,NULL,1,0,0,'These assets are ready to deploy.',NULL,0,0),(3,'Archived',1,NULL,NULL,NULL,0,0,1,'These assets are no longer in circulation or viable.',NULL,0,0);
/*!40000 ALTER TABLE `status_labels` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'VIDEOMEDIA',NULL,NULL,NULL,NULL,'MA',NULL,NULL,NULL,NULL,NULL,'2022-10-21 08:45:33','2022-10-21 08:45:33',1,NULL,NULL,NULL,NULL),(2,'PHFCOM',NULL,NULL,NULL,NULL,'MA',NULL,NULL,NULL,NULL,NULL,'2022-10-21 08:45:51','2022-10-21 08:45:51',1,NULL,NULL,NULL,'supplier-image-zMgkJSoOzA.png'),(3,'LTS NETWORK',NULL,NULL,NULL,NULL,'MA',NULL,NULL,NULL,NULL,NULL,'2022-10-21 08:46:15','2022-10-21 08:46:15',1,NULL,NULL,NULL,'supplier-image-COcSjlYKXX.png');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `throttle` WRITE;
/*!40000 ALTER TABLE `throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `throttle` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gravatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jobtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `employee_num` text COLLATE utf8mb4_unicode_ci,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `company_id` int(10) unsigned DEFAULT NULL,
  `remember_token` text COLLATE utf8mb4_unicode_ci,
  `ldap_import` tinyint(1) NOT NULL DEFAULT '0',
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'fr',
  `show_in_list` tinyint(1) NOT NULL DEFAULT '1',
  `two_factor_secret` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_enrolled` tinyint(1) NOT NULL DEFAULT '0',
  `two_factor_optin` tinyint(1) NOT NULL DEFAULT '0',
  `department_id` int(11) DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote` tinyint(1) DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `scim_externalid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`),
  KEY `users_company_id_index` (`company_id`),
  KEY `users_username_deleted_at_index` (`username`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'hamza.elfaidi@sccom.gr','$2y$10$cCoZkf0QiIZ4CmLBdSW0fuzzhY/I0U9CGsIjv6S2kAKP1eoTuCh/y','{\"superuser\":\"1\",\"admin\":\"0\",\"import\":\"0\",\"reports.view\":\"0\",\"assets.view\":\"1\",\"assets.create\":\"1\",\"assets.edit\":\"1\",\"assets.delete\":\"1\",\"assets.checkin\":\"1\",\"assets.checkout\":\"1\",\"assets.audit\":\"1\",\"assets.view.requestable\":\"1\",\"maintenances.view\":\"0\",\"maintenances.create\":\"0\",\"maintenances.edit\":\"0\",\"maintenances.delete\":\"0\",\"accessories.view\":\"0\",\"accessories.create\":\"0\",\"accessories.edit\":\"0\",\"accessories.delete\":\"0\",\"accessories.checkout\":\"0\",\"accessories.checkin\":\"0\",\"consumables.view\":\"0\",\"consumables.create\":\"0\",\"consumables.edit\":\"0\",\"consumables.delete\":\"0\",\"consumables.checkout\":\"0\",\"licenses.view\":\"0\",\"licenses.create\":\"0\",\"licenses.edit\":\"0\",\"licenses.delete\":\"0\",\"licenses.checkout\":\"0\",\"licenses.keys\":\"0\",\"licenses.files\":\"0\",\"components.view\":\"0\",\"components.create\":\"0\",\"components.edit\":\"0\",\"components.delete\":\"0\",\"components.checkout\":\"0\",\"components.checkin\":\"0\",\"users.view\":\"0\",\"users.create\":\"0\",\"users.edit\":\"0\",\"users.delete\":\"0\",\"models.view\":\"0\",\"models.create\":\"0\",\"models.edit\":\"0\",\"models.delete\":\"0\",\"categories.view\":\"0\",\"categories.create\":\"0\",\"categories.edit\":\"0\",\"categories.delete\":\"0\",\"statuslabels.view\":\"0\",\"statuslabels.create\":\"0\",\"statuslabels.edit\":\"0\",\"statuslabels.delete\":\"0\",\"customfields.view\":\"0\",\"customfields.create\":\"0\",\"customfields.edit\":\"0\",\"customfields.delete\":\"0\",\"suppliers.view\":\"0\",\"suppliers.create\":\"0\",\"suppliers.edit\":\"0\",\"suppliers.delete\":\"0\",\"manufacturers.view\":\"0\",\"manufacturers.create\":\"0\",\"manufacturers.edit\":\"0\",\"manufacturers.delete\":\"0\",\"depreciations.view\":\"0\",\"depreciations.create\":\"0\",\"depreciations.edit\":\"0\",\"depreciations.delete\":\"0\",\"locations.view\":\"0\",\"locations.create\":\"0\",\"locations.edit\":\"0\",\"locations.delete\":\"0\",\"companies.view\":\"0\",\"companies.create\":\"0\",\"companies.edit\":\"0\",\"companies.delete\":\"0\",\"self.two_factor\":\"0\",\"self.api\":\"0\",\"self.edit_location\":\"0\",\"self.checkout_assets\":\"0\"}',1,NULL,NULL,NULL,'2022-11-02 17:38:55',NULL,NULL,'Hamza','EL FAIDI','2022-10-17 17:36:47','2022-11-02 17:38:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'avatar-ym3OrPETNeig7XXe3M.jfif','hamza.elfaidi',NULL,6,'Ar0RodzeM4Vz79ntLtpr6NpDOwOBAikJiRIJ98KXUkuqA1LaszDXlAv530Rb',0,'fr',1,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),(2,'mohcin.sarrar@sccom.gr','$2y$10$kY7hZVMuN2QAMvG.Qs9cVuuFnu8YIuI.AN8BUdIyhRqfgipgaL5ES','{\"superuser\":\"1\",\"admin\":\"1\",\"import\":\"1\",\"reports.view\":\"1\",\"assets.view\":\"1\",\"assets.create\":\"1\",\"assets.edit\":\"1\",\"assets.delete\":\"1\",\"assets.checkin\":\"1\",\"assets.checkout\":\"1\",\"assets.audit\":\"1\",\"assets.view.requestable\":\"1\",\"accessories.view\":\"1\",\"accessories.create\":\"1\",\"accessories.edit\":\"1\",\"accessories.delete\":\"1\",\"accessories.checkout\":\"1\",\"accessories.checkin\":\"1\",\"consumables.view\":\"1\",\"consumables.create\":\"1\",\"consumables.edit\":\"1\",\"consumables.delete\":\"1\",\"consumables.checkout\":\"1\",\"licenses.view\":\"1\",\"licenses.create\":\"1\",\"licenses.edit\":\"1\",\"licenses.delete\":\"1\",\"licenses.checkout\":\"1\",\"licenses.keys\":\"1\",\"licenses.files\":\"1\",\"components.view\":\"1\",\"components.create\":\"1\",\"components.edit\":\"1\",\"components.delete\":\"1\",\"components.checkout\":\"1\",\"components.checkin\":\"1\",\"kits.view\":\"1\",\"kits.create\":\"1\",\"kits.edit\":\"1\",\"kits.delete\":\"1\",\"users.view\":\"1\",\"users.create\":\"1\",\"users.edit\":\"1\",\"users.delete\":\"1\",\"models.view\":\"1\",\"models.create\":\"1\",\"models.edit\":\"1\",\"models.delete\":\"1\",\"categories.view\":\"1\",\"categories.create\":\"1\",\"categories.edit\":\"1\",\"categories.delete\":\"1\",\"statuslabels.view\":\"1\",\"statuslabels.create\":\"1\",\"statuslabels.edit\":\"1\",\"statuslabels.delete\":\"1\",\"customfields.view\":\"1\",\"customfields.create\":\"1\",\"customfields.edit\":\"1\",\"customfields.delete\":\"1\",\"suppliers.view\":\"1\",\"suppliers.create\":\"1\",\"suppliers.edit\":\"1\",\"suppliers.delete\":\"1\",\"manufacturers.view\":\"1\",\"manufacturers.create\":\"1\",\"manufacturers.edit\":\"1\",\"manufacturers.delete\":\"1\",\"depreciations.view\":\"1\",\"depreciations.create\":\"1\",\"depreciations.edit\":\"1\",\"depreciations.delete\":\"1\",\"locations.view\":\"1\",\"locations.create\":\"1\",\"locations.edit\":\"1\",\"locations.delete\":\"1\",\"companies.view\":\"1\",\"companies.create\":\"1\",\"companies.edit\":\"1\",\"companies.delete\":\"1\",\"self.two_factor\":\"1\",\"self.api\":\"1\",\"self.edit_location\":\"1\",\"self.checkout_assets\":\"1\"}',1,1,NULL,NULL,'2022-10-21 14:27:23',NULL,NULL,'mohcin','sarrar','2022-10-21 10:41:08','2022-11-02 12:14:47',NULL,NULL,'MA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mohcin.sarrar',NULL,NULL,NULL,0,'fr',1,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

