<?php

return array(
    'title'      				=> 'Component Name',
    'component_tag'   	        => 'Component Tag',
);
