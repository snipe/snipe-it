<?php

return array(
    'about_manufacturers_title'     => 'About manufacturers',
    'about_manufacturers_text'      => 'Manufacturers make all the magic items we consume.',
    'asset_manufacturers'	        => 'Manufacturers',
    'create'				        => 'Create Manufacturer',
    'id'   					        => 'ID',
    'name'      			        => 'Manufacturer Name',
    'update'				        => 'Update Manufacturer',
	'total'                         => 'Total',
);
